// app.js —— 管理端状态编排
//
// 数据来源：登录页选择的独立私有数据仓库（代码仓库只托管页面，不含数据）
//
// 数据模型
//   categories.json : [{ id, name, parentId, isLeaf, sort, desc,
//                        attrs:[{key,label,type,options,required}],   // 字段定义：非末级=给下级继承；末级=物料属性
//                        attrValues:{ key: 值 } }]                    // 继承字段在本组的值（整组一份，不进物料档案）
//   materials/      : manifest + 轻量搜索索引 + 分类索引 + 完整物料分片
//   完整物料字段    : { id, categoryId, code, name,
//                        attrs:{ key: 值 },                          // 末级分组定义的字段值，每个物料各自一份
//                        location, syncedAt, createdAt, updatedAt, createdBy, updatedBy }
//
// 改动统一先进 IndexedDB 草稿（drafts），点右上角「提交管理」勾选后一次 commit 推送。
//
// 视图：materials（物料及分组） / settings（设置） / commit（提交管理）

import { CONFIG, FIELD_TYPES } from './config.js';
import * as Store from './store.js';
import * as GH from './github.js';
import * as Auth from './auth.js';
import * as Cat from './categories.js';
import * as Excel from './excel.js';
import * as MaterialStore from './material-store.js';
import { renderForm, renderAttrDefTable, mk } from './fields.js';
import { createSheet, showHoverTip, hideHoverTip, isTextTruncated } from './sheet-core.js';
import { openModal, closeModal, toastOk, toastErr, confirm, toast } from './ui.js';

// ---------- 全局状态 ----------
const state = {
  view: 'materials',
  // 远端基准（未应用草稿）
  baseCategories: [],
  baseMaterials: [],
  baseDictionaries: [],
  baseAttrSets: [],
  rawCategoriesText: '',
  rawDictionariesText: '',
  rawAttrSetsText: '',
  // 应用草稿后的展示数据
  categories: [],
  materials: [],
  dictionaries: [],
  attrSets: [],
  drafts: [],
  settings: null,
  user: null,
  remoteHead: null,
  missingDataFiles: [],      // 数据仓库首次初始化时需要创建的文件
  indexLoaded: false,        // 物料全局索引是否可展示（缓存或远端）
  indexRefreshed: false,     // 本次会话是否已从远端刷新索引（提交前必须为 true）
  indexPromise: null,        // 后台索引加载任务，提交等需要时等待
  cacheNs: '',               // 文件缓存命名空间 owner/repo@branch
  // UI 状态
  selectedCategoryId: '', // '' = 未分组（含分组异常物料）；否则为分组 id
  activeTab: 'materials',
  expanded: new Set(),
  checked: new Set(),
  search: '',
  materialPage: 1,
  materialPageSize: 20,
  materialViewSeq: 0,
  // 物料档案的展示形态：list（列表）/ sheet（表格，可在单元格内直接编辑）
  materialView: localStorage.getItem('craft.materials.view') === 'sheet' ? 'sheet' : 'list',
  sheetApi: null,
  dictChecked: new Set(),     // 字典设置页勾选
  setChecked: new Set(),      // 属性集合页勾选
  draggingCatId: null,        // 正在拖拽的分组 id
  copyingMaterials: false,    // 批量复制进行中，防止重复生成副本
  // 菜单：内置菜单写死在代码里，menu.json 只存排序/显隐/改名/图标和自定义项
  baseMenu: null,
  menu: null,
  rawMenuText: null,
  menuSearch: '',
  menuChecked: new Set(),
};

const mint = (prefix) => `${prefix}_${crypto.randomUUID().slice(0, 8)}`;
const nowISO = () => new Date().toISOString();

// 当前视图要挂到页面右栏的图标工具栏（由各面板构建时塞进来，页面统一放到右栏）
let pendingRail = null;

// 物料编码在提交时才分配：按远端最新索引算当天最大流水，避免多人同时编辑重号
// 未提交的新物料先用「待提交-哈希」做临时编码，便于识别和沟通
function tempCode(id) {
  let h = 0;
  for (const ch of String(id)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return '待提交' + h.toString(16).toUpperCase().padStart(6, '0').slice(-6);
}

function isTempCode(code) {
  return String(code || '').startsWith('待提交');
}

function todayPrefix() {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
}

async function prepareDraftsWithCodes(drafts) {
  // 只要还是临时编码就重新分配：新建后被编辑过的物料草稿会变成 update，不能只看 op
  const adds = drafts
    .filter(d => d.kind === 'material' && d.op !== 'delete')
    .filter(d => { const code = String(d.data?.code || '').trim(); return !code || isTempCode(code); })
    .sort((a, b) => String(a.data?.createdAt || '').localeCompare(String(b.data?.createdAt || ''))
      || String(a.recordId).localeCompare(String(b.recordId)));
  if (!adds.length) return drafts;

  const { items: index } = await MaterialStore.readSearchIndex();
  const prefix = todayPrefix();
  const used = new Set(index.map(item => String(item?.code || '')).filter(Boolean));
  let maxSeq = 0;
  const bump = (code) => {
    if (!code.startsWith(prefix)) return;
    const seq = Number(code.slice(prefix.length));
    if (Number.isInteger(seq) && seq > maxSeq) maxSeq = seq;
  };
  for (const code of used) bump(code);
  // 导入时自带编码的新物料保留原编码，只给空编码/临时编码的分配
  for (const draft of drafts) {
    if (draft.kind !== 'material' || draft.op === 'delete') continue;
    const code = String(draft.data?.code || '').trim();
    if (code && !isTempCode(code)) { used.add(code); bump(code); }
  }

  const assigned = new Map();
  for (const draft of adds) {
    const rawCode = String(draft.data?.code || '').trim();
    if (rawCode && !isTempCode(rawCode)) continue;
    let seq = maxSeq + 1;
    let assignedCode = prefix + String(seq).padStart(4, '0');
    while (used.has(assignedCode)) {
      seq += 1;
      assignedCode = prefix + String(seq).padStart(4, '0');
    }
    maxSeq = seq;
    used.add(assignedCode);
    assigned.set(draft.id, assignedCode);
  }
  return drafts.map(draft =>
    assigned.has(draft.id) ? { ...draft, data: { ...draft.data, code: assigned.get(draft.id) } } : draft);
}
const clone = (v) => JSON.parse(JSON.stringify(v));
const UNGROUPED = '';          // 未分组的 categoryId

// ---------- 导航菜单 ----------
// 系统内置菜单：不可删除；只能调整顺序、显隐、名称与图标
const NAV_BUILTINS = {
  materials: { label: '物料管理', icon: '▤', view: 'materials' },
  settings: {
    label: '系统设置', icon: '⚙', view: 'settings',
    children: {
      dict:   { label: '字典设置', view: 'settings', sub: 'dict' },
      set:    { label: '属性集合', view: 'settings', sub: 'set' },
      commit: { label: '提交管理', view: 'commit', badge: true },
      menu:   { label: '菜单管理', view: 'settings', sub: 'menu', locked: true },
    },
  },
  icons: { label: '图标库', icon: '◫', href: 'icons.html', newTab: true },
};
const NAV_FOOTER = { label: '返回官网', icon: '⌂', href: 'index.html' };
const NAV_ICONS = ['▦', '▤', '▥', '◫', '◈', '◉', '⧉', '☰', '≡', '⌂', '⚙', '✎',
  '⊞', '⊗', '↗', '★', '◆', '⬢', '☷', '◧', '▣', '▧'];

function defaultMenuConfig() {
  return {
    version: 1,
    order: ['materials', 'settings', 'icons'],
    children: { settings: ['dict', 'set', 'commit', 'menu'] },
    overrides: {},
    custom: [],
  };
}

// 兼容旧配置：补齐内置项、剔除失效项、保证每个菜单只出现一次，最多三级
function normalizeMenu(raw) {
  const base = defaultMenuConfig();
  const cfg = raw && typeof raw === 'object' ? raw : base;
  const custom = Array.isArray(cfg.custom) ? cfg.custom.filter(x => x && x.id) : [];
  const customIds = new Set(custom.map(c => c.id));
  const known = (key) => !!NAV_BUILTINS[key] || !!NAV_BUILTINS.settings.children[key] || customIds.has(key);
  const seen = new Set();
  const take = (list) => (Array.isArray(list) ? list : []).filter(key => {
    if (!known(key) || seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  const cfgChildren = cfg.children && typeof cfg.children === 'object' ? cfg.children : {};
  // 内置子项不能出现在一级
  const srcOrder = (Array.isArray(cfg.order) ? cfg.order : base.order)
    .filter(key => !NAV_BUILTINS.settings.children[key]);
  const out = {
    version: 1,
    order: take(srcOrder),
    children: {},
    overrides: cfg.overrides && typeof cfg.overrides === 'object' ? cfg.overrides : {},
    custom,
  };
  for (const key of Object.keys(NAV_BUILTINS)) {
    if (!seen.has(key)) { out.order.push(key); seen.add(key); }
  }

  // 子菜单：内置「系统设置」+ 自定义父项
  for (const parent of ['settings', ...custom.map(c => c.id)]) {
    const source = Array.isArray(cfgChildren[parent]) ? cfgChildren[parent]
      : parent === 'settings' ? base.children.settings : [];
    const list = take(source);
    if (parent === 'settings') {
      for (const key of base.children.settings) {
        if (!seen.has(key)) { list.push(key); seen.add(key); }
      }
    }
    if (list.length) out.children[parent] = list;
  }
  // 没出现在任何位置的菜单挂回一级
  for (const key of custom.map(c => c.id)) {
    if (!seen.has(key)) { out.order.push(key); seen.add(key); }
  }
  return out;
}

const menuOverride = (key) => (state.menu?.overrides?.[key]) || {};
// 一级菜单和「系统设置」的子项都算内置项，统一按 key 取默认定义
function menuDef(key) {
  if (NAV_BUILTINS[key]) return NAV_BUILTINS[key];
  const child = NAV_BUILTINS.settings.children[key];
  if (child) return child;
  return state.menu?.custom?.find(c => c.id === key) || null;
}
const menuLabel = (key) => menuOverride(key).label || menuDef(key)?.label || key;
const menuIcon = (key) => menuOverride(key).icon || menuDef(key)?.icon || '•';
const menuVisible = (key) => menuOverride(key).visible !== false;

// 配置数据整文件处理；物料由 MaterialStore 按分类分片处理
const DATA_SETS = [
  { kind: 'category',   path: CONFIG.categoriesPath,   base: 'baseCategories',   live: 'categories',   raw: 'rawCategoriesText' },
  { kind: 'dictionary', path: CONFIG.dictionariesPath, base: 'baseDictionaries', live: 'dictionaries', raw: 'rawDictionariesText' },
  { kind: 'attrSet',    path: CONFIG.attrSetsPath,     base: 'baseAttrSets',     live: 'attrSets',     raw: 'rawAttrSetsText' },
];

// 分组的生效属性定义（集合字段 + 自有字段）
const attrsOf = (cat) => Cat.withAttrSet(cat, state.attrSets);
// 字段定义补上字典选项，交给表单渲染
const fieldsOf = (defs) => Cat.applyDictionaries(defs, state.dictionaries);

// ---------- 启动 ----------
init().catch(e => {
  console.error(e);
  toastErr('初始化失败：' + (e.message || e));
});

// API 额度显示：头像外圈进度环 + 下拉菜单里的详情
function mountQuotaPill() {
  const ring = document.getElementById('quotaRing');
  const fill = document.getElementById('quotaRingFill');
  if (!ring || !fill) return;

  const paint = (q) => {
    const pct = q.limit ? Math.max(0, Math.min(1, q.remaining / q.limit)) : 1;
    fill.style.strokeDasharray = '100';
    fill.style.strokeDashoffset = String(100 - pct * 100);
    // 余量越低颜色越警示：≥30% 正常、10%~30% 琥珀、<10% 红
    const level = pct < 0.1 ? 'critical' : pct < 0.3 ? 'warn' : 'ok';
    // SVG 元素的 className 是只读的 SVGAnimatedString，必须用 setAttribute
    ring.setAttribute('class', 'quota-ring ' + level);

    const hm = q.reset ? formatClock(q.reset) : '';
    const amount = q.remaining == null ? '…' : `${q.remaining} / ${q.limit}`;
    const foot = q.remaining == null
      ? '尚未发起请求'
      : `本会话已请求 ${q.localUsed} 次${hm ? ` · ${hm} 重置` : ''}`;
    const elAmount = document.getElementById('quotaAmount');
    const elFill = document.getElementById('quotaFill');
    const elFoot = document.getElementById('quotaFoot');
    if (elAmount) elAmount.textContent = amount;
    if (elFill) {
      elFill.style.width = `${pct * 100}%`;
      elFill.dataset.level = level;
    }
    if (elFoot) elFoot.textContent = foot;
    const btn = document.getElementById('avatarBtn');
    if (btn) btn.title = `${document.getElementById('accountName')?.textContent || ''}｜API 剩 ${amount}${hm ? ` · ${hm} 重置` : ''}`;
  };
  paint(GH.getQuota());
  GH.onQuota(paint);
}

function formatClock(epochSec) {
  const d = new Date(epochSec * 1000);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

async function init() {
  if (!Auth.requireLogin()) return;
  state.user = Auth.getUser();
  state.settings = GH.getRepoSettings();

  // 账号信息缺失（例如只保留了 PAT）时重新取一次，头像和编辑人才能正常显示
  if (!state.user?.login) {
    try {
      Auth.saveUser(await GH.validateToken(Auth.getToken()));
      state.user = Auth.getUser();
    } catch (_) { /* 网络异常时忽略，不影响进入系统 */ }
  }

  await Store.requestPersistent();

  // 数据模型版本标记：仅记录，升级时默认保留全部本地数据，不做任何清理
  const MODEL_KEY = 'craft.modelVersion';
  const MODEL_VERSION = '5';

  bindNav();
  bindAccountBar();
  bindGlobalMaterialSearch();
  bindInfoTips();
  bindTruncatedTips();
  mountQuotaPill();
  await refreshRemote();

  if (localStorage.getItem(MODEL_KEY) !== MODEL_VERSION) {
    localStorage.setItem(MODEL_KEY, MODEL_VERSION);
  }

  await loadDrafts();
  renderNav();
  await autoFixLooseMaterials();
  render();
}

// 分组缺失或已非末级的物料：自动生成一条「改到未分组」的草稿，提交后即恢复正常
async function autoFixLooseMaterials() {
  if (!state.categories.length || !state.materials.length) return;
  const leafIds = new Set(state.categories.filter(c => c.isLeaf).map(c => c.id));
  const bad = state.materials.filter(m =>
    m.categoryId && !leafIds.has(m.categoryId) && !draftOf('material', m.id));
  if (!bad.length) return;
  try {
    const full = await hydrateMaterials(bad);
    const who = state.user?.name || state.user?.login || '';
    const drafts = full.map(m => ({
      id: `material:${m.id}`,
      kind: 'material',
      recordId: m.id,
      op: 'update',
      data: { ...m, categoryId: '', updatedAt: nowISO(), updatedBy: who || m.updatedBy || '' },
    }));
    await Store.putDrafts(drafts);
    await loadDrafts();
    toast(`已自动把 ${drafts.length} 条分组异常物料归入未分组，提交后生效`, 'warn', 4000);
  } catch (e) {
    console.warn('自动整理异常物料失败', e);
  }
}

function bindAccountBar() {
  const displayName = state.user?.name || state.user?.login || '?';
  const avatar = document.getElementById('avatarBtn');
  const menu = document.getElementById('accountDropdown');
  document.getElementById('accountName').textContent = displayName;
  document.getElementById('accountRepo').textContent =
    `数据仓库：${state.settings.owner}/${state.settings.repo} · ${state.settings.branch}`;
  if (avatar) {
    const initial = document.getElementById('avatarInitial');
    if (initial) initial.textContent = displayName.slice(0, 1).toUpperCase();
    else avatar.textContent = displayName.slice(0, 1).toUpperCase();
    avatar.title = displayName;
    avatar.addEventListener('click', e => {
      e.stopPropagation();
      menu.hidden = !menu.hidden;
    });
  }
  document.addEventListener('click', e => {
    if (menu && !menu.hidden && !e.target.closest('.account-menu')) menu.hidden = true;
  });
  document.getElementById('switchRepoBtn')?.addEventListener('click', () => {
    location.assign('login.html?step=repos');
  });
  document.getElementById('menuLogoutBtn')?.addEventListener('click', async () => {
    if (await confirm('退出登录并清除本机保存的 PAT？', '退出登录')) Auth.logout();
  });
}

function bindNav() {
  const sidebar = document.getElementById('appSidebar');
  const brand = document.getElementById('brandToggle');
  const setCollapsed = (collapsed) => {
    sidebar.classList.toggle('collapsed', collapsed);
    const action = brand?.querySelector('.brand-toggle');
    if (action) action.textContent = collapsed ? '»' : '«';
    if (brand) brand.title = collapsed ? '展开导航' : '收起导航';
  };
  // 默认收起，且不做记忆：每次刷新都回到收起态
  setCollapsed(true);
  if (brand) {
    brand.addEventListener('click', () => setCollapsed(!sidebar.classList.contains('collapsed')));
    brand.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter' && e.key !== ' ') return;
      e.preventDefault();
      brand.click();
    });
  }
  const saved = localStorage.getItem('craft.navOpen');
  toggleNavGroup(saved === '1');
}

// 渲染导航：内置菜单 + 配置里的顺序/显隐/改名/图标 + 自定义项；底部固定「返回官网」
function renderNav() {
  const nav = document.getElementById('navMenu');
  const footer = document.getElementById('navFooter');
  if (!nav) return;
  if (!state.menu) state.menu = normalizeMenu(state.baseMenu || defaultMenuConfig());
  nav.innerHTML = '';

  const iconEl = (icon) => mk('span', { class: 'nav-icon', 'aria-hidden': 'true' }, icon);
  const labelEl = (text) => mk('span', { class: 'nav-label' }, text);

  const isVisible = (key) => {
    const builtin = NAV_BUILTINS[key] || NAV_BUILTINS.settings.children[key];
    if (builtin) return menuVisible(key);
    const custom = state.menu.custom.find(c => c.id === key);
    return !!custom && custom.visible !== false;
  };

  // 递归渲染，最多三级：1 一级导航、2 二级导航、3 三级导航
  const renderItem = (key, depth) => {
    if (!isVisible(key)) return null;
    const builtin = NAV_BUILTINS[key] || NAV_BUILTINS.settings.children[key] || null;
    const custom = builtin ? null : state.menu.custom.find(c => c.id === key);
    if (!builtin && !custom) return null;

    const label = builtin ? menuLabel(key) : (custom.label || '未命名');
    const kids = (state.menu.children[key] || []).filter(isVisible);
    const isSub = depth > 1;

    if (!kids.length) {
      const a = mk('a', {
        class: 'nav-item' + (isSub ? ' nav-sub' : ''),
        href: builtin ? (builtin.href || 'javascript:;') : (custom.href || 'javascript:;'),
        title: label,
        ...(builtin?.view ? { 'data-view': builtin.view } : {}),
        ...(builtin?.sub ? { 'data-sub': builtin.sub } : {}),
      });
      const newTab = builtin ? builtin.newTab
        : (custom.href && (custom.newTab !== false || /^https?:/i.test(custom.href)));
      if (newTab) { a.setAttribute('target', '_blank'); a.setAttribute('rel', 'noopener'); }
      if (isSub) {
        a.appendChild(document.createTextNode(label));
      } else {
        a.appendChild(iconEl(builtin ? menuIcon(key) : (custom.icon || '↗')));
        a.appendChild(labelEl(label));
      }
      if (builtin?.badge) a.appendChild(mk('span', { class: 'nav-badge', id: 'commitCount', hidden: true }));
      return a;
    }

    // 带子项的分组：一级显示图标，二/三级只有文字和展开箭头
    const group = mk('div', { class: 'nav-group' + (isSub ? ' nested' : '') });
    const parent = mk('a', {
      class: 'nav-item nav-parent' + (isSub ? ' nav-sub' : ''),
      href: 'javascript:;',
      title: label,
      ...(builtin?.view ? { 'data-view': builtin.view } : {}),
    });
    if (isSub) parent.appendChild(document.createTextNode(label));
    else {
      parent.appendChild(iconEl(builtin ? menuIcon(key) : (custom.icon || '↗')));
      parent.appendChild(labelEl(label));
    }
    parent.appendChild(mk('span', { class: 'nav-caret' }, '▸'));
    group.appendChild(parent);

    const subs = mk('div', { class: 'nav-subs' });
    for (const childKey of kids) {
      const el = renderItem(childKey, depth + 1);
      if (el) subs.appendChild(el);
    }
    group.appendChild(subs);
    return group;
  };

  for (const key of state.menu.order) {
    const el = renderItem(key, 1);
    if (el) nav.appendChild(el);
  }

  // 恢复「系统设置」上次的展开状态
  if (state.navOpen) {
    const settingsParent = nav.querySelector('.nav-group:not(.nested) > .nav-parent[data-view="settings"]');
    settingsParent?.parentElement.classList.add('expanded');
  }

  if (footer) {
    footer.innerHTML = '';
    const home = mk('a', { class: 'nav-item', href: NAV_FOOTER.href, title: NAV_FOOTER.label });
    home.appendChild(iconEl(NAV_FOOTER.icon));
    home.appendChild(labelEl(NAV_FOOTER.label));
    footer.appendChild(home);
  }

  bindNavItems();
  paintActiveNav();
  updateCommitBadge();
}

// 导航项事件：点击切换视图 + 收起态浮窗
function bindNavItems() {
  const sidebar = document.getElementById('appSidebar');

  document.querySelectorAll('#navMenu .nav-item').forEach(item => {
    const isParent = item.classList.contains('nav-parent');
    if (!item.dataset.view && !isParent) return;
    item.addEventListener('click', () => {
      if (isParent) {
        // 收起态下父项没有内联二级，内置视图直接进入；浮窗由悬停控制
        if (sidebar.classList.contains('collapsed')) {
          if (item.dataset.view) switchView(item.dataset.view, item.dataset.sub);
          return;
        }
        // 自定义分组：点击展开/收起自身的子菜单；收起时一并收起所有下级
        if (!item.dataset.view) {
          const group = item.parentElement;
          const expand = !group.classList.contains('expanded');
          group.classList.toggle('expanded', expand);
          if (!expand) group.querySelectorAll('.nav-group.expanded').forEach(g => g.classList.remove('expanded'));
          return;
        }
        // 内置「系统设置」：展开态维持原来的展开/收起
        if (state.view === 'settings') { toggleNavGroup(!state.navOpen); return; }
        toggleNavGroup(true);
      }
      switchView(item.dataset.view, item.dataset.sub);
    });
  });

  // 收起态浮窗：悬停父项展开，点选条目后立即收起且不会被 hover 重新撑开
  document.querySelectorAll('#navMenu .nav-group').forEach(group => {
    const parent = group.querySelector(':scope > .nav-parent');
    const subs = group.querySelector(':scope > .nav-subs');
    if (!parent || !subs) return;
    let hideTimer = null;

    const open = () => {
      clearTimeout(hideTimer);
      if (sidebar.classList.contains('collapsed')) subs.classList.add('open');
    };
    const close = () => {
      clearTimeout(hideTimer);
      subs.classList.remove('open');
      subs.querySelectorAll('.nav-subs.open').forEach(el => el.classList.remove('open'));
    };
    const scheduleClose = () => {
      clearTimeout(hideTimer);
      hideTimer = setTimeout(close, 150);
    };

    parent.addEventListener('mouseenter', open);
    parent.addEventListener('mouseleave', scheduleClose);
    subs.addEventListener('mouseenter', () => clearTimeout(hideTimer));
    subs.addEventListener('mouseleave', scheduleClose);
    // 键盘 Tab 进入父项时同样展开
    parent.addEventListener('focus', open);
    // 点选后收起；指针可能还停在浮窗位置，这里不依赖 CSS :hover 就不会再弹开
    subs.querySelectorAll('.nav-item').forEach(sub => {
      if (sub.classList.contains('nav-parent')) return;
      sub.addEventListener('click', close);
    });
  });
}

function paintActiveNav() {
  const curSub = state.view === 'settings' ? (state.settingTab || 'dict') : null;
  document.querySelectorAll('#navMenu .nav-item').forEach(i => {
    const isSub = !!i.dataset.sub;
    const active = i.dataset.view === state.view && (!isSub || i.dataset.sub === curSub);
    i.classList.toggle('active', active);
  });
}

function bindGlobalMaterialSearch() {
  const input = document.getElementById('globalMaterialSearch');
  const resultsEl = document.getElementById('globalMaterialSearchResults');
  let matches = [];
  let timer = null;

  const close = () => resultsEl.classList.remove('open');
  const locate = (material) => {
    const target = material.categoryId ? Cat.findCategory(state.categories, material.categoryId) : null;
    // 目标分组缺失或已不是末级（物料会被隐藏）时，落在「全部物料」并按编码定位
    state.selectedCategoryId = material.categoryId && target?.isLeaf ? target.id : UNGROUPED;
    state.activeTab = 'materials';
    state.search = material.code || material.name || '';
    state.materialPage = 1;
    state.checked.clear();
    close();
    input.value = '';
    switchView('materials');
  };
  const paint = () => {
    const keyword = input.value.trim().toLowerCase();
    resultsEl.innerHTML = '';
    matches = [];
    if (!keyword) { close(); return; }
    if (!state.indexLoaded) {
      resultsEl.classList.add('open');
      resultsEl.appendChild(mk('div', { class: 'global-search-empty' }, '物料索引加载中…'));
      return;
    }
    matches = state.materials.filter(m =>
      String(m.code || '').toLowerCase().includes(keyword) ||
      String(m.name || '').toLowerCase().includes(keyword)
    ).sort((a, b) => String(a.code || '').localeCompare(String(b.code || ''), 'zh', { numeric: true }));
    resultsEl.classList.add('open');
    if (!matches.length) {
      resultsEl.appendChild(mk('div', { class: 'global-search-empty' }, '没有匹配的物料'));
      return;
    }
    for (const material of matches.slice(0, 50)) {
      const row = mk('div', { class: 'global-search-item' });
      const line = mk('div');
      line.appendChild(mk('span', { class: 'global-search-code' }, material.code || material.id));
      line.appendChild(mk('span', { class: 'global-search-name' }, material.name || ''));
      row.appendChild(line);
      const category = material.categoryId
        ? Cat.categoryPathString(state.categories, material.categoryId)
        : '未分组';
      row.appendChild(mk('div', { class: 'global-search-cat' }, category || '未分组'));
      row.addEventListener('mousedown', e => { e.preventDefault(); locate(material); });
      resultsEl.appendChild(row);
    }
    if (matches.length > 50) {
      resultsEl.appendChild(mk('div', { class: 'global-search-more' }, `共 ${matches.length} 条匹配，仅显示前 50 条，请继续缩小范围`));
    }
  };

  input.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(paint, 150);
  });
  input.addEventListener('focus', paint);
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && matches.length) { e.preventDefault(); locate(matches[0]); }
    else if (e.key === 'Escape') { close(); input.blur(); }
  });
  input.addEventListener('blur', () => setTimeout(close, 100));
}

// 二级导航展开/收起（状态持久化到 localStorage）
function toggleNavGroup(open) {
  state.navOpen = !!open;
  // 每个一级分组独立展开，避免打开「系统设置」时把其他自定义分组一起展开
  const parent = document.querySelector('#navMenu .nav-group:not(.nested) > .nav-parent[data-view="settings"]');
  parent?.parentElement.classList.toggle('expanded', state.navOpen);
  localStorage.setItem('craft.navOpen', state.navOpen ? '1' : '0');
}

function switchView(view, sub) {
  state.view = view;
  if (view === 'settings' && sub) state.settingTab = sub;
  paintActiveNav();
  const titles = {
    materials: menuLabel('materials'),
    settings: menuLabel('settings'),
    commit: menuLabel('commit'),
  };
  document.getElementById('topbarTitle').textContent = titles[view] || '';
  render();
}

function render() {
  const content = document.getElementById('content');
  content.className = 'content';
  content.innerHTML = '';
  renderNav();   // 菜单配置可能在别处变过（提交、同步），随页面一起重绘
  if (state.view === 'materials') renderMaterialsPage();
  else if (state.view === 'settings') renderSettings();
  else if (state.view === 'commit') renderCommit();
}

// ---------- 远端读取 ----------
// 首屏只等仓库校验、分支、设置文件和物料清单；全局索引体积大，随后台任务补上。
const INDEX_CACHE_KEY = 'materials.index.v1';
// 首屏快速索引缓存按仓库隔离，避免切换数据仓库后串数据
const indexCacheKey = () => `${INDEX_CACHE_KEY}:${state.cacheNs}`;

async function refreshRemote({ awaitIndex = false } = {}) {
  state.indexRefreshed = false;
  setLoading();
  progressStart('连接数据仓库…');
  const totalSteps = 3 + DATA_SETS.length;
  try {
    const texts = {};
    state.missingDataFiles = [];

    // 先确认仓库可访问，避免把“无权限”误判成“空仓库”
    try {
      await GH.getRepo(state.settings.owner, state.settings.repo);
      progressSet(1, totalSteps, '读取数据…');
    } catch (e) {
      if (e.status === 401) {
        Auth.clearToken();
        Auth.clearUser();
        location.replace('login.html');
        return;
      }
      if (e.status === 404) {
        toastErr('数据仓库不存在或当前 PAT 无权访问，请重新选择仓库');
        return;
      }
      throw e;
    }

    // 先取分支 HEAD：它决定本地文件缓存是否还有效，之后的文件读取都先查缓存
    const head = await GH.getBranchHead(state.settings.branch).catch(() => null);
    progressAdvance('读取分支…');
    const ns = `${state.settings.owner}/${state.settings.repo}@${state.settings.branch}`;
    state.cacheNs = ns;
    GH.setCacheContext(ns, head);

    // 三个设置文件、菜单配置、物料清单并行读取；head 未变时直接命中 IndexedDB 缓存
    const [files, menuFile, materialData] = await Promise.all([
      Promise.all(DATA_SETS.map(s => GH.getFile(s.path).then(f => {
        progressAdvance('读取数据…');
        return f;
      }))),
      GH.getFile(CONFIG.menuPath).then(f => {
        progressAdvance('读取菜单…');
        return f;
      }),
      MaterialStore.loadManifest().then(data => {
        progressAdvance('读取物料清单…');
        return data;
      }),
    ]);

    state.remoteHead = head;
    DATA_SETS.forEach((s, i) => {
      const f = files[i];
      texts[s.kind] = f ? f.content : null;
      if (!f) state.missingDataFiles.push(s.path);
    });

    for (const s of DATA_SETS) {
      state[s.base] = texts[s.kind] ? safeParse(texts[s.kind], []) : [];
      state[s.raw] = texts[s.kind] || null;
    }
    state.rawMenuText = menuFile ? menuFile.content : null;
    state.baseMenu = normalizeMenu(menuFile ? safeParse(menuFile.content, defaultMenuConfig()) : defaultMenuConfig());
    state.missingDataFiles.push(...materialData.missingPaths);

    // 上次成功加载的索引先顶上，首屏就能看到计数，不必等大文件下载
    if (!state.indexLoaded) {
      const cached = await Store.getMeta(indexCacheKey()).catch(() => null);
      if (Array.isArray(cached) && cached.length) {
        state.baseMaterials = cached;
        state.indexLoaded = true;
      }
    }
  } catch (e) {
    console.warn('远端读取失败', e);
    state.missingDataFiles = [];
    toastErr('数据仓库读取失败：' + (e.message || e));
  } finally {
    progressEnd();
  }

  state.indexPromise = loadMaterialIndex();
  if (awaitIndex) return state.indexPromise;
  return true;
}

// 后台加载全局索引：到达后合并计数、启用全局搜索，并写入本地缓存供下次首屏使用
async function loadMaterialIndex() {
  state.indexRefreshed = false;
  try {
    const data = await MaterialStore.loadIndex();
    state.baseMaterials = data.materials;
    state.indexLoaded = true;
    state.indexRefreshed = true;
    state.missingDataFiles = [
      ...state.missingDataFiles.filter(p => p !== CONFIG.materialsSearchIndexPath),
      ...data.missingPaths,
    ];
    Store.setMeta(indexCacheKey(), data.materials).catch(e => console.warn('缓存物料索引失败', e));
    await autoFixLooseMaterials();
    await loadDrafts();
    // 弹窗打开时可能正在编辑，先不重绘背景；关闭后其他操作会重新渲染
    if (state.view === 'materials' && document.getElementById('modalMask')?.classList.contains('hidden')) render();
    else if (state.view === 'commit') render();
    return true;
  } catch (e) {
    state.indexRefreshed = false;
    console.warn('物料索引加载失败', e);
    if (state.indexLoaded) toast('物料索引刷新失败，当前显示上次缓存的数据', 'warn', 4000);
    else toastErr('物料索引加载失败：' + (e.message || e));
    if (state.view === 'materials') render();
    return false;
  }
}

function safeParse(text, fallback) {
  try { return JSON.parse(text) || fallback; } catch (_) { return fallback; }
}

// ---------- 草稿 ----------
async function loadDrafts() {
  state.drafts = await Store.listDrafts();
  applyDrafts();
  updateCommitBadge();
}

function applyDrafts() {
  const sets = {};
  for (const s of DATA_SETS) sets[s.kind] = clone(state[s.base]);
  const materials = clone(state.baseMaterials);

  for (const d of state.drafts) {
    if (d.kind === 'material') {
      const idx = materials.findIndex(x => x.id === d.recordId);
      if (d.op === 'delete') {
        if (idx >= 0) materials.splice(idx, 1);
        continue;
      }
      const previous = idx >= 0 ? materials[idx] : null;
      const summary = {
        id: d.data.id,
        categoryId: d.data.categoryId || '',
        code: d.data.code || '',
        name: d.data.name || '',
        updatedAt: d.data.updatedAt || d.data.createdAt || '',
        updatedBy: d.data.updatedBy || '',
        path: previous?.path || '',
      };
      if (idx >= 0) materials[idx] = summary;
      else materials.push(summary);
      continue;
    }
    const target = sets[d.kind];
    if (!target) continue;
    const idx = target.findIndex(x => x.id === d.recordId);
    if (d.op === 'delete') {
      if (idx >= 0) target.splice(idx, 1);
    } else if (d.op === 'add') {
      if (idx < 0) target.push(clone(d.data));
    } else {
      if (idx >= 0) target[idx] = clone(d.data);
      else target.push(clone(d.data));
    }
  }

  for (const s of DATA_SETS) state[s.live] = sets[s.kind];

  // 菜单：内置项来自代码，草稿覆盖顺序/显隐/改名/图标并追加自定义项
  const menuDraft = state.drafts.find(d => d.kind === 'menu');
  state.menu = normalizeMenu(menuDraft ? menuDraft.data : state.baseMenu);
  state.materials = materials;

  // 选中的分组若被删掉则回退到未分组
  if (state.selectedCategoryId !== UNGROUPED && !state.categories.some(c => c.id === state.selectedCategoryId)) {
    state.selectedCategoryId = UNGROUPED;
  }
}

function updateCommitBadge() {
  const initCount = state.missingDataFiles.length ? 1 : 0;
  const count = state.drafts.length + initCount;
  const el = document.getElementById('commitCount');
  if (!el) return;
  el.hidden = !count;
  el.textContent = count;
}

async function saveCategoryDraft(cat, op) {
  await Store.putDraft({
    id: `category:${cat.id}`,
    kind: 'category',
    recordId: cat.id,
    op,
    data: clone(cat),
  });
  await loadDrafts();
}

function makeMaterialDraft(mat, op) {
  const who = state.user?.name || state.user?.login || '';
  const next = {
    ...mat,
    createdAt: mat.createdAt || nowISO(),
    updatedAt: mat.updatedAt || nowISO(),
    createdBy: mat.createdBy || (op === 'add' ? who : ''),
    updatedBy: who || mat.updatedBy || '',
  };
  return {
    id: `material:${next.id}`,
    kind: 'material',
    recordId: next.id,
    op,
    data: clone(next),
  };
}

async function saveMaterialDraft(mat, op) {
  await Store.putDraft(makeMaterialDraft(mat, op));
  await loadDrafts();
}

async function saveDictionaryDraft(dict, op) {
  await Store.putDraft({
    id: `dictionary:${dict.id}`,
    kind: 'dictionary',
    recordId: dict.id,
    op,
    data: clone(dict),
  });
  await loadDrafts();
}

async function saveAttrSetDraft(set, op) {
  await Store.putDraft({
    id: `attrSet:${set.id}`,
    kind: 'attrSet',
    recordId: set.id,
    op,
    data: clone(set),
  });
  await loadDrafts();
}

// 判断某条记录当前是否有未提交改动
function draftOf(kind, id) {
  return state.drafts.find(d => d.kind === kind && d.recordId === id) || null;
}

async function hydrateMaterials(entries, onProgress) {
  const remoteEntries = entries.filter(entry => {
    const draft = draftOf('material', entry.id);
    return !draft || draft.op === 'delete';
  });
  const remote = await MaterialStore.hydrate(remoteEntries, onProgress);
  const byId = new Map(remote.map(item => [item.id, item]));
  return entries.map(entry => {
    const draft = draftOf('material', entry.id);
    if (draft && draft.op !== 'delete') return clone(draft.data);
    const record = byId.get(entry.id);
    if (!record) throw new Error(`物料 ${entry.code || entry.id} 加载失败`);
    return record;
  });
}

async function getMaterialById(id) {
  const summary = state.materials.find(item => item.id === id);
  if (!summary) return null;
  return (await hydrateMaterials([summary]))[0];
}

// ---------- 物料及分组页 ----------
function renderMaterialsPage() {
  const content = document.getElementById('content');
  content.className = 'content';
  content.innerHTML = '';

  const page = mk('div', { class: 'cat-page' });
  pendingRail = null;
  const treePanel = buildTreePanel();
  page.appendChild(treePanel);
  page.appendChild(buildPanelResizer(treePanel));   // 分组栏可拖宽，深层目录名不被挤掉
  page.appendChild(buildCatMain());
  page.appendChild(pendingRail || buildSideRail());   // 右栏：页面级图标工具栏
  content.appendChild(page);
}

// 分组栏宽度拖拽：拖动时实时改宽度，松手落 localStorage（下次打开沿用）
function buildPanelResizer(panel) {
  const KEY = 'craft.ui.treeWidth';
  const saved = Number(localStorage.getItem(KEY));
  if (saved >= 180) panel.style.width = `${saved}px`;

  const grip = mk('div', { class: 'panel-resizer', title: '拖动调整分组栏宽度（双击恢复默认）' });
  const onMove = (e) => {
    const w = Math.max(180, Math.min(560, panel._startW + e.clientX - panel._startX));
    panel.style.width = `${w}px`;
  };
  const onUp = () => {
    document.removeEventListener('mousemove', onMove);
    document.removeEventListener('mouseup', onUp);
    document.body.classList.remove('col-resizing');
    localStorage.setItem(KEY, String(panel.offsetWidth));
  };
  grip.addEventListener('mousedown', (e) => {
    panel._startX = e.clientX;
    panel._startW = panel.offsetWidth;
    document.body.classList.add('col-resizing');
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    e.preventDefault();
  });
  grip.addEventListener('dblclick', () => {
    panel.style.width = '236px';
    localStorage.setItem(KEY, '236');
  });
  return grip;
}

function buildTreePanel() {
  const panel = mk('div', { class: 'cat-panel' });
  const head = mk('div', { class: 'cat-panel-head' });
  const ttl = mk('span', { class: 'ttl' }, '分组');
  // 全部物料总数（叠加未提交的新增/删除），紧跟“分组”显示
  let totalMaterials = state.baseMaterials.length;
  for (const draft of state.drafts) {
    if (draft.kind !== 'material') continue;
    if (draft.op === 'add') totalMaterials += 1;
    else if (draft.op === 'delete' && state.baseMaterials.some(item => item.id === draft.recordId)) totalMaterials -= 1;
  }
  ttl.appendChild(mk('span', { class: 'tree-total', style: 'margin-left:6px;font-size:12px;color:var(--text-muted);font-weight:400;' },
    state.indexLoaded ? String(totalMaterials) : '…'));
  head.appendChild(ttl);
  const addBtn = mk('button', { class: 'btn small', title: '新建分组', 'aria-label': '新建分组' }, '＋');
  addBtn.addEventListener('click', () => openCategoryDialog(null));
  head.appendChild(addBtn);
  panel.appendChild(head);

  // 当前分组只显示自身名称（末级）；完整路径放在悬停提示里
  const curCat = state.selectedCategoryId && state.selectedCategoryId !== UNGROUPED
    ? Cat.findCategory(state.categories, state.selectedCategoryId) : null;
  const curName = curCat ? curCat.name : '未分组';
  const fullPath = curCat ? Cat.categoryPathString(state.categories, curCat.id) : '未分组（散落在各分组之外的物料）';
  panel.appendChild(mk('div', { class: 'tree-path', title: fullPath }, curName));

  const tree = mk('div', { class: 'tree' });

  // 固定的「未分组」：同时收纳分组缺失或已非末级的异常物料
  const leafIds = new Set(state.categories.filter(c => c.isLeaf).map(c => c.id));
  const ungroupedCount = state.materials.filter(m => !m.categoryId || !leafIds.has(m.categoryId)).length;
  tree.appendChild(buildTreeNode({
    depth: 0,
    label: '未分组',
    count: state.indexLoaded ? ungroupedCount : '…',
    active: state.selectedCategoryId === UNGROUPED,
    isRoot: true,
    onClick: () => { state.selectedCategoryId = UNGROUPED; state.activeTab = 'materials'; state.materialPage = 1; state.checked.clear(); render(); },
  }));

  const roots = Cat.buildTree(state.categories);
  const renderNodes = (nodes, depth) => {
    for (const node of nodes) {
      const hasKids = (node.children || []).length > 0;
      const isOpen = state.expanded.has(node.id);
      const count = state.materials.filter(m => m.categoryId === node.id).length;

      tree.appendChild(buildTreeNode({
        id: node.id,
        parentId: node.parentId ?? null,
        depth,
        label: node.name,
        count: state.indexLoaded ? count : '…',
        active: state.selectedCategoryId === node.id,
        hasKids,
        isOpen,
        isLeaf: node.isLeaf,
        onCaret: (e) => {
          e.stopPropagation();
          if (isOpen) state.expanded.delete(node.id);
          else state.expanded.add(node.id);
          render();
        },
        onClick: () => {
          state.selectedCategoryId = node.id;
          state.activeTab = node.isLeaf ? 'materials' : 'manage';
          state.materialPage = 1;
          state.checked.clear();
          if (hasKids) state.expanded.add(node.id);
          render();
        },
        onAdd: (e) => { e.stopPropagation(); openCategoryDialog(node.id); },
      }));

      if (hasKids && isOpen) renderNodes(node.children, depth + 1);
    }
  };
  renderNodes(roots, 0);

  // 拖到树空白处 → 移到根级
  tree.addEventListener('dragover', (e) => {
    if (!state.draggingCatId) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    tree.classList.add('drop-root');
  });
  tree.addEventListener('dragleave', (e) => {
    if (e.target === tree) tree.classList.remove('drop-root');
  });
  tree.addEventListener('drop', (e) => {
    if (!state.draggingCatId) return;
    e.preventDefault();
    tree.classList.remove('drop-root');
    doMoveCategory(state.draggingCatId, null, null);
  });

  if (!roots.length) {
    tree.appendChild(mk('div', { class: 'empty', style: 'padding:24px 10px;' }, '还没有分组'));
  }

  panel.appendChild(tree);
  return panel;
}

function buildTreeNode(opts) {
  const node = mk('div', {
    class: 'tree-node' + (opts.active ? ' active' : '') + (opts.isRoot ? ' is-root' : ''),
    style: `--depth:${opts.depth}`,
  });

  const caret = mk('span', { class: 'caret' + (opts.hasKids ? '' : ' hidden-caret') },
    opts.hasKids ? (opts.isOpen ? '▾' : '▸') : '·');
  if (opts.hasKids) caret.addEventListener('click', opts.onCaret);
  node.appendChild(caret);

  const labelEl = mk('span', { class: 'tree-label' }, opts.label);
  node.appendChild(labelEl);
  if (opts.count) node.appendChild(mk('span', { class: 'tree-count' }, String(opts.count)));

  // 末级分组不能再挂子分组，不显示 ＋
  if (!opts.isRoot && !opts.isLeaf) {
    const add = mk('button', { class: 'node-add', title: '新建子分组' }, '＋');
    add.addEventListener('click', opts.onAdd);
    node.appendChild(add);
  }

  node.addEventListener('click', opts.onClick);

  // 拖拽调整层级/顺序（「未分组」虚拟节点不参与）
  if (opts.id) wireTreeNodeDrag(node, opts);
  return node;
}

// 节点三分区：上 1/4 插到前面（同级）、下 1/4 插到后面（同级）、中间作为子级
function dropZoneOf(e, el) {
  const r = el.getBoundingClientRect();
  const y = e.clientY - r.top;
  if (y < r.height * 0.25) return 'before';
  if (y > r.height * 0.75) return 'after';
  return 'into';
}

function clearDropMarks(el) {
  el.classList.remove('drop-before', 'drop-into', 'drop-after');
}

function wireTreeNodeDrag(node, opts) {
  node.draggable = true;

  node.addEventListener('dragstart', (e) => {
    state.draggingCatId = opts.id;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', opts.id);
    node.classList.add('dragging');
  });
  node.addEventListener('dragend', () => {
    state.draggingCatId = null;
    node.classList.remove('dragging');
    document.querySelectorAll('.tree-node.drop-before,.tree-node.drop-into,.tree-node.drop-after')
      .forEach(clearDropMarks);
    document.querySelector('.tree')?.classList.remove('drop-root');
  });

  node.addEventListener('dragover', (e) => {
    if (!state.draggingCatId || state.draggingCatId === opts.id) return;
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = 'move';
    clearDropMarks(node);
    node.classList.add('drop-' + dropZoneOf(e, node));
  });
  node.addEventListener('dragleave', () => clearDropMarks(node));
  node.addEventListener('drop', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const zone = dropZoneOf(e, node);
    clearDropMarks(node);
    const dragId = state.draggingCatId;
    if (!dragId || dragId === opts.id) return;
    if (zone === 'into') doMoveCategory(dragId, opts.id, null);
    else doMoveCategory(dragId, opts.parentId, zone === 'before' ? opts.id : nextSiblingIdOf(opts));
  });
}

// 「插到某节点之后」= 插到它下一个同级之前；没有下一个就是末尾（null）
function nextSiblingIdOf(opts) {
  const siblings = state.categories
    .filter(c => (c.parentId ?? null) === (opts.parentId ?? null) && c.id !== state.draggingCatId)
    .sort((a, b) => (a.sort ?? 0) - (b.sort ?? 0) || a.name.localeCompare(b.name, 'zh'));
  const idx = siblings.findIndex(c => c.id === opts.id);
  return idx >= 0 && idx + 1 < siblings.length ? siblings[idx + 1].id : null;
}

// 执行移动：校验 → 存草稿 → 刷新
async function doMoveCategory(id, newParentId, beforeId) {
  const np = newParentId ?? null;
  const node = Cat.findCategory(state.categories, id);
  if (!node) return;
  // 末级分组不能再挂子分组（先在「分组管理」里取消末级）
  const target = np ? Cat.findCategory(state.categories, np) : null;
  if (target && target.isLeaf && np !== (node.parentId ?? null)) {
    toastErr('末级分组不能挂子分组，请先在「分组管理」里取消末级');
    return;
  }
  // 目标父级已挂物料时不能再挂子分组，否则那些物料会失去入口
  if (np && np !== (node.parentId ?? null) && state.materials.some(m => m.categoryId === np)) {
    toastErr('目标分组下已有物料，不能再挂子分组');
    return;
  }
  // 位置没变就不动
  if ((node.parentId ?? null) === np && !beforeId) return;

  const cats = clone(state.categories);
  const changed = Cat.moveCategory(cats, id, np, beforeId);
  if (!changed.length) { toastErr('不能移动到该位置'); return; }
  for (const c of changed) {
    const d = draftOf('category', c.id);
    await saveCategoryDraft(c, d?.op === 'add' ? 'add' : 'update');
  }
  if (np) state.expanded.add(np);
  state.checked.clear();
  render();
  toastOk('分组已移动（草稿）');
}

function buildCatMain() {
  const main = mk('div', { class: 'cat-main' });
  const cat = state.selectedCategoryId ? Cat.findCategory(state.categories, state.selectedCategoryId) : null;

  // 选项卡：末级分组或未分组才有「物料档案」；分组有「分组管理」
  const tabs = [];
  if (!cat || cat.isLeaf) tabs.push({ id: 'materials', label: '物料档案' });
  if (cat) tabs.push({ id: 'manage', label: '分组管理' });

  if (!tabs.some(t => t.id === state.activeTab)) {
    state.activeTab = tabs[0]?.id || 'materials';
  }

  const tabBar = mk('div', { class: 'tabs' });
  for (const t of tabs) {
    const btn = mk('button', { class: 'tab' + (state.activeTab === t.id ? ' active' : '') }, t.label);
    btn.addEventListener('click', () => { state.activeTab = t.id; render(); });
    tabBar.appendChild(btn);
  }
  main.appendChild(tabBar);

  if (state.activeTab === 'materials') main.appendChild(buildMaterialsPanel(cat));
  else if (cat) main.appendChild(buildManagePanel(cat));

  return main;
}

// ---------- 物料档案 ----------
// 分组缺失或已非末级：物料无法在分组树里看到，统一收进「未分组」
function isLooseCategory(categoryId) {
  if (!categoryId) return true;
  const category = Cat.findCategory(state.categories, categoryId);
  return !category || !category.isLeaf;
}

async function currentMaterialSummaries() {
  const categoryId = state.selectedCategoryId || UNGROUPED;

  // 未分组：真正的未分组 + 分组缺失/非末级的异常物料
  if (categoryId === UNGROUPED) {
    const leafIds = new Set(state.categories.filter(c => c.isLeaf).map(c => c.id));
    const loose = (id) => !id || !leafIds.has(id);
    const records = await MaterialStore.listCategory(UNGROUPED);
    const byId = new Map(records.map(item => [item.id, item]));
    for (const item of state.materials) {
      if (!loose(item.categoryId)) continue;
      byId.set(item.id, item);
    }
    for (const draft of state.drafts) {
      if (draft.kind !== 'material') continue;
      const base = state.baseMaterials.find(item => item.id === draft.recordId);
      if (base && loose(base.categoryId)) byId.delete(base.id);
      if (draft.op !== 'delete' && loose(draft.data.categoryId)) {
        byId.set(draft.recordId, {
          id: draft.recordId,
          categoryId: draft.data.categoryId || '',
          code: draft.data.code || '',
          name: draft.data.name || '',
          updatedAt: draft.data.updatedAt || draft.data.createdAt || '',
          updatedBy: draft.data.updatedBy || '',
          path: base?.path || '',
        });
      }
    }
    const kw = state.search.trim().toLowerCase();
    let list = Array.from(byId.values());
    if (kw) {
      list = list.filter(m =>
        String(m.code || '').toLowerCase().includes(kw) ||
        String(m.name || '').toLowerCase().includes(kw));
    }
    return list.sort((a, b) =>
      String(a.code || '').localeCompare(String(b.code || ''), 'zh', { numeric: true }));
  }

  const records = await MaterialStore.listCategory(categoryId);
  const byId = new Map(records.map(item => [item.id, item]));

  // 分类索引只包含云端数据，本地新增、修改、删除和跨组移动在这里叠加。
  for (const draft of state.drafts) {
    if (draft.kind !== 'material') continue;
    const base = state.baseMaterials.find(item => item.id === draft.recordId);
    if (base && (base.categoryId || '') === categoryId) byId.delete(base.id);
    if (draft.op !== 'delete' && (draft.data.categoryId || '') === categoryId) {
      byId.set(draft.recordId, {
        id: draft.recordId,
        categoryId,
        code: draft.data.code || '',
        name: draft.data.name || '',
        updatedAt: draft.data.updatedAt || draft.data.createdAt || '',
        updatedBy: draft.data.updatedBy || '',
        path: base?.path || '',
      });
    }
  }

  const keyword = state.search.trim().toLowerCase();
  let list = Array.from(byId.values());
  if (keyword) {
    list = list.filter(m =>
      String(m.code || '').toLowerCase().includes(keyword) ||
      String(m.name || '').toLowerCase().includes(keyword));
  }
  return list.sort((a, b) =>
    String(a.code || '').localeCompare(String(b.code || ''), 'zh', { numeric: true }));
}

async function currentMaterials(onProgress) {
  const summaries = await currentMaterialSummaries();
  return hydrateMaterials(summaries, onProgress);
}

function buildMaterialsPanel(cat) {
  const panel = mk('div', { class: 'tab-panel' });

  const bar = mk('div', { class: 'toolbar' });
  const search = mk('input', { type: 'search', placeholder: state.selectedCategoryId === UNGROUPED ? '搜索当前分类：物料编码 / 名称' : '搜索当前分类：物料编码 / 名称' });
  search.value = state.search;
  let searchTimer = null;
  search.addEventListener('input', e => {
    state.search = e.target.value;
    state.materialPage = 1;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => refreshMaterialsTable(panel, cat), 150);
  });
  bar.appendChild(search);

  const info = mk('span', { class: 'hint materials-count' });
  bar.appendChild(info);
  bar.appendChild(mk('span', { class: 'spacer' }));
  const selHint = mk('span', { class: 'hint', id: 'materialsSelectedHint' });
  selHint.textContent = state.checked.size ? `已选 ${state.checked.size} 项` : '';
  bar.appendChild(selHint);
  panel.appendChild(bar);

  const body = mk('div', { class: 'materials-body' });
  const main = mk('div', { class: 'materials-main' });
  const tableWrap = mk('div', { class: 'table-wrap', id: 'materialsTableWrap' });
  main.appendChild(tableWrap);
  // 底部：翻页固定在右下角
  const footer = mk('div', { class: 'materials-footer' });
  footer.appendChild(mk('div', { class: 'materials-pagination', id: 'materialsPagination' }));
  main.appendChild(footer);
  body.appendChild(main);
  panel.appendChild(body);

  refreshMaterialsTable(panel, cat);
  return panel;
}

// 页面右侧竖排批量操作栏（参考图二最右红框）
function buildSideRail() {
  const rail = mk('div', { class: 'side-rail' });
  const sep = () => mk('div', { class: 'rail-sep' });

  const add = mk('button', { class: 'rail-btn', title: '新增物料' }, '＋');
  add.addEventListener('click', () => openMaterialDialog(null));

  const imp = mk('button', { class: 'rail-btn', title: '导入 Excel' }, '⤓');
  imp.addEventListener('click', () => triggerImport());

  const exp = mk('button', { class: 'rail-btn', title: '导出当前筛选为 Excel' }, '⤒');
  exp.addEventListener('click', () => doExport());

  const move = mk('button', { class: 'rail-btn', id: 'moveMaterialsBtn', title: '批量转移分组（先勾选）' }, '⇄');
  move.disabled = !state.checked.size;
  move.addEventListener('click', () => openBatchMoveDialog());

  const copy = mk('button', { class: 'rail-btn', id: 'copyMaterialsBtn', title: '复制选中物料（先勾选）' }, '⧉');
  copy.disabled = !state.checked.size || state.copyingMaterials;
  copy.addEventListener('click', () => doCopyMaterial());

  const del = mk('button', { class: 'rail-btn danger-hover', id: 'deleteMaterialsBtn', title: '批量删除（先勾选）' }, '✕');
  del.disabled = !state.checked.size;
  del.addEventListener('click', () => doBatchDelete());

  rail.appendChild(add);
  rail.appendChild(sep());
  rail.appendChild(imp);
  rail.appendChild(exp);
  rail.appendChild(sep());
  rail.appendChild(copy);
  rail.appendChild(move);
  rail.appendChild(del);

  // 工具栏底部：视图切换（列表显示表格图标，表格显示列表图标）
  const sheetMode = state.materialView === 'sheet';
  const viewToggle = mk('button', {
    class: 'rail-btn',
    style: 'margin-top: auto;',
    title: sheetMode ? '切换到列表视图' : '切换到表格视图',
  }, sheetMode ? '☰' : '▦');
  viewToggle.addEventListener('click', () => {
    state.materialView = sheetMode ? 'list' : 'sheet';
    localStorage.setItem('craft.materials.view', state.materialView);
    render();
  });
  rail.appendChild(viewToggle);
  return rail;
}

// 表格视图勾选后局部刷新工具栏状态，避免整页重绘把已加载的数据丢掉
function syncSelectionUi() {
  const n = state.checked.size;
  const hint = document.getElementById('materialsSelectedHint');
  if (hint) hint.textContent = n ? `已选 ${n} 项` : '';
  const copy = document.getElementById('copyMaterialsBtn');
  const move = document.getElementById('moveMaterialsBtn');
  const del = document.getElementById('deleteMaterialsBtn');
  if (copy) copy.disabled = !n || state.copyingMaterials;
  if (move) move.disabled = !n;
  if (del) del.disabled = !n;
}

function refreshMaterialsTable(panel, cat) {
  renderMaterialsTable(panel, cat).catch(e => {
    console.error(e);
    if (panel.isConnected) toastErr('物料加载失败：' + (e.message || e));
  });
}

async function renderMaterialsTable(panel, cat) {
  const wrap = panel.querySelector('#materialsTableWrap');
  const info = panel.querySelector('.materials-count');
  const pagination = panel.querySelector('#materialsPagination');
  if (!wrap) return;
  const seq = ++state.materialViewSeq;
  if (state.sheetApi) { state.sheetApi.destroy(); state.sheetApi = null; }
  wrap.classList.remove('sheet-wrap');
  wrap.innerHTML = '';
  wrap.appendChild(mk('div', { class: 'empty', style: 'padding:24px;' }, '加载中…'));
  if (pagination) pagination.innerHTML = '';

  // 全局索引尚未就绪时不发分片请求，等后台加载完成后由 loadMaterialIndex 重绘
  if (!state.indexLoaded) {
    wrap.innerHTML = '';
    wrap.appendChild(mk('div', { class: 'empty', style: 'padding:24px;' }, '物料索引加载中…'));
    if (info) info.textContent = '正在加载物料索引…';
    return;
  }

  let summaries;
  try {
    summaries = await currentMaterialSummaries();
    if (seq !== state.materialViewSeq) return;
  } catch (e) {
    if (seq === state.materialViewSeq) {
      wrap.innerHTML = '';
      wrap.appendChild(mk('div', { class: 'empty', style: 'padding:24px;' }, '加载失败：' + (e.message || e)));
    }
    throw e;
  }
  if (seq !== state.materialViewSeq || !panel.isConnected) return;

  wrap.innerHTML = '';
  const isSheet = state.materialView === 'sheet';
  const footer = pagination ? pagination.closest('.materials-footer') : null;
  if (footer) footer.style.display = isSheet ? 'none' : '';
  if (info) info.textContent = isSheet ? `共 ${summaries.length} 条` : `共 ${summaries.length} 条，每页 ${state.materialPageSize} 条`;

  // 表格视图：不分页，竖直滚动按窗口渲染，数据分批加载
  if (isSheet) {
    if (pagination) pagination.innerHTML = '';
    await renderSheetView(wrap, summaries, cat);
    return;
  }

  const totalPages = Math.max(1, Math.ceil(summaries.length / state.materialPageSize));
  state.materialPage = Math.min(Math.max(1, state.materialPage), totalPages);
  const start = (state.materialPage - 1) * state.materialPageSize;
  // 列表只用索引摘要渲染；完整档案在编辑、导出、批量操作时再按分片加载
  const list = summaries.slice(start, start + state.materialPageSize);
  if (pagination) {
    const prev = mk('button', { class: 'btn small' }, '上一页');
    prev.disabled = state.materialPage <= 1;
    prev.addEventListener('click', () => {
      state.materialPage--;
      refreshMaterialsTable(panel, cat);
    });
    const next = mk('button', { class: 'btn small' }, '下一页');
    next.disabled = state.materialPage >= totalPages;
    next.addEventListener('click', () => {
      state.materialPage++;
      refreshMaterialsTable(panel, cat);
    });
    pagination.appendChild(prev);
    pagination.appendChild(mk('span', { class: 'page-info' }, `第 ${state.materialPage} / ${totalPages} 页`));
    pagination.appendChild(next);
  }

  const table = mk('table', { class: 'grid' });
  const head = mk('tr');
  const chkAll = mk('input', { type: 'checkbox', title: '全选本页' });
  const allVisibleChecked = list.length > 0 && list.every(m => state.checked.has(m.id));
  chkAll.checked = allVisibleChecked;
  chkAll.addEventListener('change', () => {
    if (chkAll.checked) list.forEach(m => state.checked.add(m.id));
    else list.forEach(m => state.checked.delete(m.id));
    render();
  });

  // 摘要里没有属性值，列表只保留固定列；属性在编辑弹窗里查看和修改
  const thChk = mk('th', { class: 'col-chk' });
  thChk.appendChild(chkAll);
  head.appendChild(thChk);
  const headLabels = ['物料编码', '物料名称', '保存状态', '最近编辑时间', '编辑人'];
  const headClasses = ['col-code', 'col-name', 'col-attr', 'col-attr', 'col-attr'];
  headLabels.forEach((t, i) => head.appendChild(mk('th', { class: headClasses[i] }, t)));
  head.appendChild(mk('th', { class: 'col-ops' }, '操作'));
  table.appendChild(head);

  if (!list.length) {
    const tr = mk('tr');
    tr.appendChild(mk('td', { colspan: 7, class: 'empty' }, '暂无物料'));
    table.appendChild(tr);
  }

  for (const m of list) {
    const d = draftOf('material', m.id);
    const tr = mk('tr', { class: d ? 'dirty' : '' });

    const tdChk = mk('td', { class: 'col-chk' });
    const chk = mk('input', { type: 'checkbox' });
    chk.checked = state.checked.has(m.id);
    chk.addEventListener('change', () => {
      if (chk.checked) state.checked.add(m.id); else state.checked.delete(m.id);
      render();
    });
    tdChk.appendChild(chk);
    tr.appendChild(tdChk);

    tr.appendChild(mk('td', { class: 'col-code' + (isTempCode(m.code) ? ' muted' : '') }, m.code || '待提交'));
    tr.appendChild(mk('td', { class: 'col-name' }, m.name || ''));
    const locTd = mk('td', { class: 'col-attr' });
    locTd.appendChild(buildLocationCell(m));
    tr.appendChild(locTd);

    const editTd = mk('td', { class: 'muted col-attr', style: 'font-size:12px;' },
      fmtTime(m.updatedAt));
    tr.appendChild(editTd);

    const byTd = mk('td', { class: 'muted col-attr', style: 'font-size:12px;' }, m.updatedBy || '—');
    tr.appendChild(byTd);

    const opsTd = mk('td', { class: 'col-ops' });
    const editBtn = mk('button', { class: 'link-btn' }, '编辑');
    // 行里只有摘要，打开编辑弹窗时才按分片加载完整档案
    editBtn.addEventListener('click', async () => {
      if (editBtn.disabled) return;
      editBtn.disabled = true;
      try {
        const full = await getMaterialById(m.id);
        if (full) openMaterialDialog(full);
      } catch (e) {
        toastErr('物料加载失败：' + (e.message || e));
      } finally {
        editBtn.disabled = false;
      }
    });
    const delBtn = mk('button', { class: 'link-btn danger' }, '删除');
    delBtn.addEventListener('click', () => doDeleteMaterial(m));
    opsTd.appendChild(editBtn);
    opsTd.appendChild(delBtn);
    tr.appendChild(opsTd);

    table.appendChild(tr);
  }

  wrap.appendChild(table);

  // 固定列偏移：勾选框列宽 + 编码列宽 → 「物料名称」的 left
  const pinColumns = () => {
    const chk = table.querySelector('th.col-chk');
    const code = table.querySelector('th.col-code');
    if (!chk || !code) return;
    const left1 = chk.offsetWidth;
    const left2 = left1 + code.offsetWidth;
    table.querySelectorAll('.col-code').forEach(el => { el.style.left = `${left1}px`; });
    table.querySelectorAll('.col-name').forEach(el => { el.style.left = `${left2}px`; });
  };
  pinColumns();
  requestAnimationFrame(pinColumns);
  if (wrap._pinObserver) wrap._pinObserver.disconnect();
  if (window.ResizeObserver) {
    wrap._pinObserver = new ResizeObserver(() => pinColumns());
    wrap._pinObserver.observe(wrap);
  }
}

// ---------- 表格视图（电子表格内核） ----------
const SHEET_TYPES = {
  text: 'text', textarea: 'text', number: 'number', select: 'select', radio: 'radio',
  multiselect: 'multiselect', multiselectDropdown: 'multiselectDropdown', range: 'range', date: 'date', checkbox: 'bool',
};

// 属性列在表格里的 key 加前缀，避免和编码/名称等固定列冲突
const ATTR_PREFIX = 'attr_';

async function renderSheetView(wrap, summaries, cat) {
  wrap.classList.add('sheet-wrap');
  wrap.innerHTML = '';
  const seq = state.materialViewSeq;
  const defs = cat && cat.isLeaf ? fieldsOf(attrsOf(cat)) : [];

  const byId = new Map();       // 展示值（已叠加草稿）
  const baseById = new Map();   // 远端基准值：用来判断哪些格子真的改过
  const sameVal = (a, b) => JSON.stringify(a ?? '') === JSON.stringify(b ?? '');
  // 只在「内容确实和远端不同」时标记；改回原值标记随之消失
  function cellDirty(id, key) {
    const mat = byId.get(id), base = baseById.get(id);
    if (!mat || !base) return false;
    if (key === 'name') return String(mat.name || '') !== String(base.name || '');
    if (key.startsWith(ATTR_PREFIX)) {
      const k = key.slice(ATTR_PREFIX.length);
      return !sameVal(mat.attrs?.[k], base.attrs?.[k]);
    }
    return false;
  }
  function rowDirty(id) {
    if (cellDirty(id, 'name')) return true;
    return defs.some(def => cellDirty(id, ATTR_PREFIX + def.key));
  }

  let api = null;
  const columns = [
    {
      key: '__chk', label: '', width: 36, readonly: true, freeze: true, align: 'center',
      render: (row) => `<input type="checkbox" class="sheet-chk" data-rid="${row._id}"${state.checked.has(row._id) ? ' checked' : ''}>`,
      headRender: () => {
        const rows = api ? api.getRows() : [];
        const all = rows.length > 0 && rows.every(r => state.checked.has(r._id));
        return `<input type="checkbox" class="sheet-chk-all"${all ? ' checked' : ''} title="全选已加载">`;
      },
    },
    { key: 'code', label: '物料编码', readonly: true, freeze: true, width: 120 },
    { key: 'name', label: '物料名称', freeze: true, width: 220, cellClass: (row) => cellDirty(row._id, 'name') ? 'sc-cell-dirty' : '' },
    ...defs.map(def => {
      const key = ATTR_PREFIX + def.key;
      return {
        key,
        label: def.label || def.key,
        type: SHEET_TYPES[def.type] || 'text',
        width: def.type === 'textarea' ? 220 : 140,
        required: !!def.required,
        options: (def.options || []).map(v => ({ value: v, label: def.optionsLabels?.[v] || v })),
        cellClass: (row) => cellDirty(row._id, key) ? 'sc-cell-dirty' : '',
      };
    }),
  ];

  const host = mk('div', { class: 'sheet-host' });
  wrap.appendChild(host);
  api = createSheet(host, {
    columns,
    rows: [],
    features: { toolbar: false, search: false, log: false, export: false },
    onError: (msg) => toastErr(msg),
    onChange: (patches) => saveSheetEdits(patches, byId, baseById, rowDirty),
  });
  state.sheetApi = api;

  const info = wrap.closest('.tab-panel')?.querySelector('.materials-count');
  const toRow = (mat) => {
    const values = { code: mat.code || '待提交', name: mat.name || '' };
    for (const def of defs) values[ATTR_PREFIX + def.key] = mat.attrs?.[def.key] ?? '';
    return { _id: mat.id, values, dirty: rowDirty(mat.id) };
  };

  // 分批加载：先是首屏一批，滚动接近底部再取下一批
  const BATCH = 200;
  let loaded = 0;
  let loading = false;
  async function loadMore() {
    if (loading || loaded >= summaries.length) return;
    loading = true;
    const batch = summaries.slice(loaded, loaded + BATCH);
    let failed = false;
    try {
      const records = await hydrateMaterials(batch);
      if (seq !== state.materialViewSeq || !host.isConnected) return;
      // 有草稿的物料额外取远端基准，用于「改回原值取消标记」；失败就退回加载时快照
      const drafted = batch.filter(entry => {
        const d = draftOf('material', entry.id);
        return d && d.op !== 'delete';
      });
      let remoteBase = [];
      if (drafted.length) {
        try { remoteBase = await MaterialStore.hydrate(drafted); } catch (_) { remoteBase = []; }
      }
      if (seq !== state.materialViewSeq || !host.isConnected) return;
      for (const mat of records) byId.set(mat.id, mat);
      for (const base of remoteBase) baseById.set(base.id, base);
      for (const mat of records) if (!baseById.has(mat.id)) baseById.set(mat.id, clone(mat));
      api.appendRows(records.map(toRow));
      loaded += batch.length;
      if (info) info.textContent = `共 ${summaries.length} 条${loaded < summaries.length ? `（已加载 ${loaded}）` : ''}`;
    } catch (e) {
      failed = true;
      if (seq === state.materialViewSeq) toastErr('物料加载失败：' + (e.message || e));
    } finally {
      loading = false;
    }
    if (failed) { loaded = summaries.length; return; }
    // 内容不足一屏时继续补下一批
    const scroller = host.querySelector('.sc-scroll');
    if (scroller && loaded < summaries.length && scroller.scrollHeight <= scroller.clientHeight + 120) {
      setTimeout(() => { if (seq === state.materialViewSeq) loadMore(); }, 0);
    }
  }

  const scroller = host.querySelector('.sc-scroll');
  scroller?.addEventListener('scroll', () => {
    if (loading || loaded >= summaries.length) return;
    if (scroller.scrollTop + scroller.clientHeight > scroller.scrollHeight - 600) loadMore();
  });

  // 勾选列：与列表视图共用 state.checked，只局部刷新工具栏
  host.addEventListener('change', (e) => {
    const t = e.target;
    if (t.classList?.contains('sheet-chk')) {
      if (t.checked) state.checked.add(t.dataset.rid); else state.checked.delete(t.dataset.rid);
      api.paint();
      syncSelectionUi();
    } else if (t.classList?.contains('sheet-chk-all')) {
      const rows = api.getRows();
      if (t.checked) rows.forEach(r => state.checked.add(r._id));
      else rows.forEach(r => state.checked.delete(r._id));
      api.paint();
      syncSelectionUi();
    }
  });

  await loadMore();
}

// 单元格编辑 → 物料草稿（内容改回远端原值时自动撤掉草稿）
async function saveSheetEdits(patches, byId, baseById, rowDirty) {
  const touched = new Set();
  for (const p of patches) {
    const mat = byId.get(p.rowId);
    if (!mat) continue;
    const key = String(p.key);
    if (key === 'name') {
      const name = String(p.next ?? '').trim();
      if (!name) { toastErr('物料名称不能为空'); continue; }
      mat.name = name;
    } else if (key.startsWith(ATTR_PREFIX)) {
      mat.attrs = { ...(mat.attrs || {}), [key.slice(ATTR_PREFIX.length)]: p.next };
    } else {
      continue;
    }
    mat.updatedAt = nowISO();
    mat.updatedBy = state.user?.login || mat.updatedBy || '';
    touched.add(mat);
  }
  for (const mat of touched) {
    const existing = draftOf('material', mat.id);
    const base = baseById.get(mat.id);
    // 新增的物料没有远端版本，草稿必须保留；其余改回原值就删草稿
    if (existing && existing.op !== 'add' && base && !materialChanged(mat, base)) {
      await Store.removeDraft('material', mat.id);
      await loadDrafts();
    } else {
      await saveMaterialDraft(mat, existing ? existing.op : 'update');
    }
  }
  const api = state.sheetApi;
  if (!api) return;
  for (const row of api.getRows()) row.dirty = rowDirty(row._id);
  api.paint();
}

// 与远端基准比对（忽略 updatedAt/updatedBy 这类每次编辑都会变的字段）
function materialChanged(a, b) {
  if (String(a.name || '') !== String(b.name || '')) return true;
  if (String(a.categoryId || '') !== String(b.categoryId || '')) return true;
  if (String(a.code || '') !== String(b.code || '')) return true;
  return attrSignature(a.attrs) !== attrSignature(b.attrs);
}
function attrSignature(attrs) {
  const src = attrs || {};
  return JSON.stringify(Object.keys(src).sort().map(k => [k, src[k] ?? '']));
}

// 保存状态：已保存=与仓库一致，未保存=还有未提交的本地改动
function buildLocationCell(m) {  // 所属分组缺失或已非末级：物料在分组树里看不到，状态直接标红提示
  if (m.categoryId && isLooseCategory(m.categoryId)) {
    const span = mk('span', { class: 'loc warn', title: '所属分组已不存在或不是末级分组', style: 'color:var(--danger);' });
    span.appendChild(mk('i', { class: 'dot', style: 'background:var(--danger);' }));
    span.appendChild(document.createTextNode('异常'));
    return span;
  }
  const isSaved = !draftOf('material', m.id);
  const span = mk('span', { class: 'loc', title: isSaved ? '已提交到数据仓库' : '有未提交的本地改动' });
  span.appendChild(mk('i', { class: `dot ${isSaved ? 'cloud' : 'local'}` }));
  span.appendChild(document.createTextNode(isSaved ? '已保存' : '未保存'));
  return span;
}

function fmtTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return String(iso);
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function leafCategories() {
  return state.categories.filter(c => c.isLeaf && !state.categories.some(x => x.parentId === c.id));
}

// ---------- 物料编辑弹窗 ----------
function openMaterialDialog(mat) {
  const isNew = !mat;

  // 在哪个分组下点的新增，物料就进哪个分组；弹窗里不再重复选择
  const catId = mat ? (isLooseCategory(mat.categoryId) ? UNGROUPED : mat.categoryId)
    : (state.selectedCategoryId || UNGROUPED);
  const cat = catId ? Cat.findCategory(state.categories, catId) : null;
  // 只有末级分组自己定义的字段才进物料表单（上级定义的字段在分组上统一填，不进物料档案）
  // 末级分组的生效字段（属性集合 + 自有字段），选项来自字典
  const defs = fieldsOf(attrsOf(cat));

  const newId = mint('m');
  let current = mat
    ? clone(mat)
    : {
        id: newId, categoryId: catId || UNGROUPED, code: tempCode(newId), name: '',
        attrs: {}, location: 'local', syncedAt: '',
        createdAt: nowISO(), updatedAt: nowISO(), createdBy: '', updatedBy: '',
      };

  const body = mk('div');

  const fields = [
    { key: 'code', label: '物料编码', type: 'text', required: !isNew },
    { key: 'name', label: '物料名称', type: 'text', required: true },
    ...defs,
  ];
  const flat = { code: current.code, name: current.name, ...(current.attrs || {}) };
  const form = renderForm({ fields }, { fields: flat });
  body.appendChild(form.root);

  // 物料编码由系统生成，不允许手改
  const codeInput = form.root.querySelector('#f-code');
  if (codeInput) {
    codeInput.readOnly = true;
    codeInput.title = '临时编码，提交时自动生成正式编码';
  }
  body.appendChild(mk('div', { class: 'muted', style: 'margin-top:6px;font-size:12px;' },
    isNew ? '暂用临时编码，提交后按「年月日 + 四位流水号」生成正式编码' : '物料编码按「年月日 + 四位流水号」自动生成'));

  // 保存状态（只读）：有未提交草稿=未保存，与仓库一致=已保存
  const locLine = mk('div', { class: 'muted', style: 'margin-top:12px;font-size:12px;' });
  const locKey = (isNew || draftOf('material', current.id)) ? 'local' : 'cloud';
  locLine.textContent = `保存状态：${locKey === 'cloud' ? '已保存' : '未保存'}` +
    (locKey === 'cloud' && current.syncedAt ? `　最近同步：${fmtTime(current.syncedAt)}` : '　（提交后变为已保存）');
  body.appendChild(locLine);

  if (!isNew) {
    body.appendChild(mk('div', { class: 'muted', style: 'margin-top:6px;font-size:12px;' },
      `创建：${current.createdBy || '—'}　${fmtTime(current.createdAt)}　` +
      `最近编辑：${current.updatedBy || '—'}　${fmtTime(current.updatedAt)}`));
  }

  openModal({
    title: isNew ? '新增物料' : '编辑物料',
    body,
    actions: [
      { label: '取消', onClick: closeModal },
      {
        label: '保存草稿', className: 'primary',
        onClick: async () => {
          const errs = form.errors();
          if (errs.length) { toastErr('校验未通过：' + errs.join('；')); return; }
          const v = form.read();
          // 物料编码全局唯一（导入也按编码匹配）
          const code = String(v.code || '').trim();
          if (code && state.materials.some(m => m.id !== current.id && (m.code || '') === code)) {
            toastErr(`物料编码「${code}」已存在`);
            return;
          }
          // 末级分组的字段值，每个物料各自存一份
          const attrs = {};
          for (const def of defs) {
            const val = v[def.key];
            if (val === '' || val == null) continue;
            if (Array.isArray(val) && !val.length) continue;
            if (def.type === 'range' && val.min === '' && val.max === '') continue;
            attrs[def.key] = val;
          }
          const data = {
            ...current,
            code,
            name: String(v.name || '').trim(),
            attrs,
            updatedAt: nowISO(),
            location: current.location === 'cloud' ? 'cloud' : 'local',
          };
          // 还没提交过的新物料，编辑后仍是新增草稿，否则会丢掉「待分配编码」的状态
          const existingDraft = draftOf('material', current.id);
          await saveMaterialDraft(data, isNew || existingDraft?.op === 'add' ? 'add' : 'update');
          closeModal();
          render();
          toastOk('已存为草稿');
        },
      },
    ],
  });
}

async function doDeleteMaterial(m) {
  const d = draftOf('material', m.id);
  if (!(await confirm(`确定删除物料「${m.name || m.code || m.id}」？`))) return;
  if (d?.op === 'add') {
    await Store.removeDraft('material', m.id);
    await loadDrafts();
  } else {
    await saveMaterialDraft({ ...m }, 'delete');
  }
  state.checked.delete(m.id);
  render();
  toastOk('已标记为删除');
}

// ---------- 批量操作 ----------
// 复制选中物料：每条生成新编码、保留原分组、属性值深拷贝，名称加「（副本）」
async function doCopyMaterial() {
  if (state.copyingMaterials) return;
  const ids = Array.from(state.checked);
  if (!ids.length) { toastErr('请先勾选物料再复制'); return; }
  state.copyingMaterials = true;
  const copyButton = document.getElementById('copyMaterialsBtn');
  if (copyButton) copyButton.disabled = true;
  const summaries = ids.map(id => state.materials.find(item => item.id === id)).filter(Boolean);
  progressStart('加载物料分片…');
  try {
    const sources = await hydrateMaterials(summaries,
      (done, total) => progressSet(done, total, '加载物料分片'));
    const drafts = sources.map(src => {
      const copyId = mint('m');
      return makeMaterialDraft({
        id: copyId,
        categoryId: src.categoryId || '',
        code: tempCode(copyId),
        name: `${src.name || src.code}（副本）`,
        attrs: clone(src.attrs || {}),
        location: 'local',
        syncedAt: '',
        createdAt: nowISO(),
        updatedAt: nowISO(),
        createdBy: '',
        updatedBy: '',
      }, 'add');
    });
    await Store.putDrafts(drafts);
    await loadDrafts();
    state.checked.clear();
    render();
    toastOk(`已复制 ${sources.length} 条物料，提交后生成编码`);
  } catch (e) {
    toastErr('批量复制失败：' + (e.message || e));
  } finally {
    state.copyingMaterials = false;
    const currentCopyButton = document.getElementById('copyMaterialsBtn');
    if (currentCopyButton) currentCopyButton.disabled = !state.checked.size;
    progressEnd();
  }
}

// ---------- 分组选择器（可搜索下拉） ----------
// 分组多了以后原生下拉很难翻，这里用「输入过滤 + 下拉列表」：
// 聚焦显示全部，输入即按路径模糊过滤，↑↓ 移动、Enter 选中、Esc 关闭。
// 列表挂在 body 上 fixed 定位，避免被弹窗的滚动区裁剪；空间不足时自动向上展开。
function buildCategoryPicker(options, currentValue) {
  const opts = options.map(o => ({ id: o.id == null ? '' : String(o.id), label: o.label }));
  const wrap = mk('div', { class: 'picker' });
  const input = mk('input', { type: 'text', placeholder: '输入关键字过滤分组…', autocomplete: 'off', spellcheck: false });
  const list = mk('div', { class: 'picker-list' });
  wrap.appendChild(input);

  let value = currentValue == null ? '' : String(currentValue);
  let rows = [];
  let hover = -1;

  const labelOf = (v) => (opts.find(o => o.id === v) || {}).label || '';
  const syncInput = () => { input.value = labelOf(value); };

  function syncPos() {
    const r = input.getBoundingClientRect();
    const maxH = Math.min(220, window.innerHeight - 16);
    list.style.left = r.left + 'px';
    list.style.width = r.width + 'px';
    const below = window.innerHeight - r.bottom - 8;
    const up = below < 120 && r.top > below;
    if (up) {
      list.style.top = '';
      list.style.bottom = (window.innerHeight - r.top + 4) + 'px';
    } else {
      list.style.bottom = '';
      list.style.top = (r.bottom + 4) + 'px';
    }
  }
  const onWinChange = () => { if (list.classList.contains('open')) syncPos(); };

  function openList() {
    if (list.classList.contains('open')) return;
    document.body.appendChild(list);
    list.classList.add('open');
    syncPos();
    window.addEventListener('resize', onWinChange);
    window.addEventListener('scroll', onWinChange, true);
  }
  function closeList() {
    list.classList.remove('open');
    list.remove();
    window.removeEventListener('resize', onWinChange);
    window.removeEventListener('scroll', onWinChange, true);
  }

  function setHover(i) {
    hover = i;
    rows.forEach((r, idx) => r.classList.toggle('hover', idx === i));
    if (rows[i]) rows[i].scrollIntoView({ block: 'nearest' });
  }

  function paint(keyword) {
    list.innerHTML = '';
    rows = [];
    hover = -1;
    const kw = String(keyword || '').trim().toLowerCase();
    const hit = opts.filter(o => !kw || o.label.toLowerCase().includes(kw));
    if (!hit.length) { list.appendChild(mk('div', { class: 'picker-empty' }, '没有匹配的分组')); return; }
    for (const o of hit) {
      const row = mk('div', { class: 'picker-item' + (o.id === value ? ' active' : ''), title: o.label }, o.label);
      row.__opt = o;
      row.addEventListener('mouseenter', () => setHover(rows.indexOf(row)));
      row.addEventListener('mousedown', (e) => { e.preventDefault(); choose(o); });
      rows.push(row);
      list.appendChild(row);
    }
  }

  function choose(o) {
    value = o.id;
    syncInput();
    closeList();
    input.blur();
  }

  input.addEventListener('focus', () => {
    openList();
    paint('');
    input.select();
    setHover(rows.findIndex(r => r.classList.contains('active')));
  });
  input.addEventListener('input', () => { openList(); paint(input.value); syncPos(); });
  input.addEventListener('blur', () => { closeList(); syncInput(); });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (!list.classList.contains('open')) { openList(); paint(''); }
      if (rows.length) setHover((hover + 1) % rows.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (rows.length) setHover((hover - 1 + rows.length) % rows.length);
    } else if (e.key === 'Enter') {
      if (hover >= 0 && rows[hover]) { e.preventDefault(); choose(rows[hover].__opt); }
    } else if (e.key === 'Escape') {
      closeList();
      syncInput();
      input.blur();
    }
  });

  syncInput();
  return { el: wrap, get value() { return value; } };
}

function openBatchMoveDialog() {
  const ids = Array.from(state.checked);
  if (!ids.length) { toastErr('请先勾选物料'); return; }
  const leaves = leafCategories();

  const body = mk('div');
  body.appendChild(mk('p', { class: 'muted' }, `已选 ${ids.length} 条物料，转移到：`));

  const opts = [{ id: UNGROUPED, label: '未分组' }]
    .concat(leaves.map(c => ({ id: c.id, label: Cat.categoryPathString(state.categories, c.id) }))
      .sort((a, b) => a.label.localeCompare(b.label, 'zh')));
  const picker = buildCategoryPicker(opts, UNGROUPED);
  body.appendChild(picker.el);
  // 没有末级分组时弹窗会只剩“未分组”，直接说明原因和去处
  if (!leaves.length) {
    body.appendChild(mk('div', { class: 'muted', style: 'margin-top:10px;font-size:12px;color:var(--danger);' },
      '当前没有末级分组：物料只能挂到末级分组。请先在左侧选中分组，到「分组管理」勾选「末级分组」，再回来转移。'));
  }

  openModal({
    title: '批量转移分组',
    body,
    actions: [
      { label: '取消', onClick: closeModal },
      {
        label: '确认转移', className: 'primary',
        onClick: async () => {
          const target = picker.value;
          const summaries = ids.map(id => state.materials.find(item => item.id === id)).filter(Boolean);
          progressStart('加载物料分片…');
          try {
            const materials = await hydrateMaterials(summaries,
              (done, total) => progressSet(done, total, '加载物料分片'));
            const drafts = materials.map(m => {
              const d = draftOf('material', m.id);
              const op = d?.op === 'add' ? 'add' : 'update';
              return makeMaterialDraft({ ...m, categoryId: target, updatedAt: nowISO() }, op);
            });
            await Store.putDrafts(drafts);
            await loadDrafts();
            closeModal();
            render();
            toastOk(`已转移 ${ids.length} 条物料`);
          } catch (e) {
            toastErr('批量转移失败：' + (e.message || e));
          } finally {
            progressEnd();
          }
        },
      },
    ],
  });
}

async function doBatchDelete() {
  const ids = Array.from(state.checked);
  if (!ids.length) { toastErr('请先勾选物料'); return; }
  if (!(await confirm(`确定删除选中的 ${ids.length} 条物料？`))) return;
  const summaries = ids.map(id => state.materials.find(item => item.id === id)).filter(Boolean);
  progressStart('加载物料分片…');
  try {
    const materials = await hydrateMaterials(summaries,
      (done, total) => progressSet(done, total, '加载物料分片'));
    const drafts = [];
    const addedIds = [];
    for (const m of materials) {
      const d = draftOf('material', m.id);
      if (d?.op === 'add') addedIds.push(m.id);
      else drafts.push(makeMaterialDraft({ ...m }, 'delete'));
    }
    await Store.putDrafts(drafts);
    await Store.removeDrafts('material', addedIds);
    state.checked.clear();
    await loadDrafts();
    render();
    toastOk(`已删除 ${ids.length} 条（草稿）`);
  } catch (e) {
    toastErr('批量删除失败：' + (e.message || e));
  } finally {
    progressEnd();
  }
}

// ---------- Excel 导入导出 ----------
async function doExport() {
  progressStart('加载物料分片…');
  try {
    const list = await currentMaterials((done, total) => progressSet(done, total, '加载物料分片'));
    if (!list.length) { toastErr('当前没有可导出的物料'); return; }
    // 物料位置按同步状态推导：有未提交草稿=本地
    const rows = list.map(m => ({ ...m, location: draftOf('material', m.id) ? 'local' : 'cloud' }));
    // 文件名用当前分组名：父级分组导出时代表整个子树
    const groupName = state.selectedCategoryId
      ? Cat.findCategory(state.categories, state.selectedCategoryId)?.name
      : '未分组';
    const n = Excel.exportMaterials(rows, state.categories, state.attrSets, state.dictionaries, groupName);
    toastOk(`已导出 ${n} 条物料`);
  } catch (e) {
    toastErr('导出失败：' + (e.message || e));
  } finally {
    progressEnd();
  }
}

function triggerImport() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.xlsx,.xls';
  input.addEventListener('change', async () => {
    if (!input.files?.length) return;
    const file = input.files[0];
    try {
      const rows = await Excel.parseMaterialsFile(file);
      await openImportPreview(rows, file.name);
    } catch (e) {
      toastErr('读取失败：' + (e.message || e));
    }
  });
  input.click();
}

async function openImportPreview(rows, fileName) {
  if (!rows.length) { toastErr('文件里没有数据行'); return; }

  // 在副本上预演，避免改动真实数据
  const cats = clone(state.categories);
  const plan = { updates: [], inserts: [], createdCats: [] };

  for (const row of rows) {
    const segs = row.groupNames || [];
    // 分组列为空 → 未分组（虚拟节点，categoryId 为空字符串）
    let categoryId = UNGROUPED;
    if (segs.length) {
      const r = Cat.resolveOrCreatePath(cats, segs, () => mint('c'));
      categoryId = r.categoryId;
      for (const c of r.created) plan.createdCats.push(c);
    }

    const existingSummary = (row.id && state.materials.find(m => m.id === row.id))
      || (row.code && state.materials.find(m => m.code === row.code))
      || null;
    const existing = existingSummary ? await getMaterialById(existingSummary.id) : null;

    const targetCatId = categoryId;

    // 属性列按「显示名 = 字段定义 label」匹配；分组级属性在分组上维护，不在这里读
    const importCat = Cat.findCategory(cats, targetCatId);
    const importedAttrs = {};
    for (const def of fieldsOf(attrsOf(importCat))) {
      const raw = row.raw?.[def.label];
      const parsed = Cat.parseAttrValue(def, Cat.attrValueFromDisplay(def, raw));
      if (parsed !== undefined) importedAttrs[def.key] = parsed;
    }

    const rowId = existing?.id || row.id || mint('m');
    const data = {
      ...(existing || {
        id: rowId,
        createdAt: nowISO(), createdBy: '', updatedBy: '',
        location: 'local', syncedAt: '', attrs: {},
      }),
      categoryId: targetCatId,
      code: row.code || existing?.code || tempCode(rowId),
      name: row.name || existing?.name || '',
      // Excel 里有值的属性覆盖，Excel 为空的保留原值（避免把已有数据清空）
      attrs: { ...(existing?.attrs || {}), ...importedAttrs },
      updatedAt: nowISO(),
    };
    if (existing) plan.updates.push({ existing, data });
    else plan.inserts.push({ data });
  }

  const body = mk('div');
  body.appendChild(mk('p', {}, `文件：${fileName}`));
  const ul = mk('ul', { style: 'margin:8px 0 0;padding-left:18px;' });
  ul.appendChild(mk('li', {}, `更新已有物料：${plan.updates.length} 条`));
  ul.appendChild(mk('li', {}, `新增物料：${plan.inserts.length} 条`));
  ul.appendChild(mk('li', {}, `需新建分组：${plan.createdCats.length} 个`));
  body.appendChild(ul);
  body.appendChild(mk('p', { class: 'muted', style: 'margin-top:10px;font-size:12px;' },
    '导入只会写入本地草稿，仍需到「提交管理」统一提交才会生效。'));

  openModal({
    title: '导入预览',
    body,
    actions: [
      { label: '取消', onClick: closeModal },
      {
        label: '写入草稿', className: 'primary',
        onClick: async () => {
          const drafts = [];
          const addDraft = (kind, data, op) => drafts.push({
            id: `${kind}:${data.id}`, kind, recordId: data.id, op, data: clone(data),
          });
          for (const c of plan.createdCats) {
            const existingDraft = draftOf('category', c.id);
            addDraft('category', c, existingDraft?.op === 'update' ? 'update' : 'add');
          }
          for (const u of plan.updates) {
            const d = draftOf('material', u.existing.id);
            addDraft('material', u.data, d?.op === 'add' ? 'add' : 'update');
          }
          for (const i of plan.inserts) addDraft('material', i.data, 'add');
          await Store.putDrafts(drafts);
          await loadDrafts();

          closeModal();
          render();
          toastOk(`已写入草稿：更新 ${plan.updates.length} / 新增 ${plan.inserts.length}`);
        },
      },
    ],
  });
}

// ---------- 分组管理（统一保存） ----------
// 板块1 分组属性：名称/排序/末级/描述
// 板块2 本级属性值：直接父级定义的字段，本组填值（整组一份，不进物料档案）；父级没定义则不显示
// 板块3 继承的属性：更高层祖先定义的字段，只读显示上级已填的值；没有则不显示
// 板块4 物料属性（字段定义）：非末级=下级自动继承（下级在「本级属性值」填值）；末级=进物料档案
function buildManagePanel(cat) {
  const panel = mk('div', { class: 'tab-panel' });
  const body = mk('div', { class: 'materials-body' });
  // 左侧表单内容列（可滚动），右侧图标工具栏（保存 / 删除）
  const formCol = mk('div', { class: 'manage-flat', style: 'flex:1; min-width:0; overflow-y:auto; padding:2px 4px 2px 2px;' });

  // 板块 1：分组属性
  const s1 = mk('div', { class: 'section' });
  s1.appendChild(sectionTitle(1, '分组属性'));
  const formGrid = mk('div', { class: 'form-grid' });

  const nameInput = mk('input', { type: 'text', value: cat.name || '' });
  const sortInput = mk('input', { type: 'number', value: cat.sort ?? 0 });
  const descInput = mk('textarea', { rows: 2 });
  descInput.value = cat.desc || '';

  const kids = Cat.childIds(state.categories, cat.id);
  const matCount = state.materials.filter(m => m.categoryId === cat.id).length;
  const leafChk = mk('input', { type: 'checkbox' });
  leafChk.checked = !!cat.isLeaf;
  leafChk.disabled = kids.length > 0 || (leafChk.checked && matCount > 0);
  const leafWrap = mk('label', { class: 'checkbox-label' });
  leafWrap.appendChild(leafChk);
  leafWrap.appendChild(document.createTextNode('末级分组'));
  leafWrap.appendChild(infoTip(
    kids.length ? '已有下一级分组，不可设为末级'
      : leafChk.checked && matCount > 0 ? `该分组下还有 ${matCount} 条物料，不能改为非末级；请先转移或删除这些物料`
        : '勾选后可挂物料档案'));

  formGrid.appendChild(fieldBox('名称', nameInput));
  formGrid.appendChild(fieldBox('排序', sortInput));
  formGrid.appendChild(fieldBox('是否末级', leafWrap));
  const descBox = fieldBox('描述', descInput);
  descBox.classList.add('full');
  formGrid.appendChild(descBox);
  s1.appendChild(formGrid);
  formCol.appendChild(s1);

  // 本级属性值：直接父级定义的字段，本组在这里填值（整组一份，不进物料档案，可编辑）
  // 继承的属性：更高层祖先定义的字段，显示上级已填好的值（只读，要改请到对应分组）
  let secIdx = 1;
  const chain = Cat.categoryPath(state.categories, cat.id).slice(0, -1); // 祖先链，根在前
  const directParent = chain[chain.length - 1] || null;
  const parentDefs = fieldsOf(attrsOf(directParent)).map(a => ({ ...a, fromCategory: directParent.name }));
  const parentKeys = new Set(parentDefs.map(a => a.key));
  // 更高层祖先的字段：同 key 就近覆盖；直接父级已定义的（归本级属性值）不重复显示
  const ancestorDefMap = new Map();
  for (const anc of chain.slice(0, -1)) {
    for (const a of fieldsOf(attrsOf(anc))) {
      if (!parentKeys.has(a.key)) ancestorDefMap.set(a.key, { ...a, fromCategory: anc.name });
    }
  }
  const ancestorDefs = Array.from(ancestorDefMap.values());
  // 继承值 = 父级整条链的生效值（就近覆盖）
  const inheritedVals = directParent ? Cat.effectiveValues(state.categories, directParent.id) : {};

  let ownForm = null;
  if (parentDefs.length) {
    const s = mk('div', { class: 'section' });
    s.appendChild(sectionTitle(++secIdx, '本级属性值',
      `由上级分组「${directParent.name}」定义的字段，这里填本组的值；整个分组一份，不进物料档案`));
    ownForm = renderForm({ fields: parentDefs }, { fields: cat.attrValues || {} });
    s.appendChild(ownForm.root);
    formCol.appendChild(s);
  }
  if (ancestorDefs.length) {
    const s = mk('div', { class: 'section' });
    s.appendChild(sectionTitle(++secIdx, '继承的属性', '更高层分组定义、上级已填好的值，只读；要改请到对应分组修改'));
    const grid = mk('div', { class: 'form-grid' });
    for (const def of ancestorDefs) {
      const inp = mk('input', {
        type: 'text',
        value: Cat.fmtAttrValue(def, inheritedVals[def.key]),
        disabled: true,
        placeholder: '（上级未填）',
      });
      const box = fieldBox(def.label, inp);
      box.querySelector('label').appendChild(mk('span', { class: 'from-tag' }, ` 来自 ${def.fromCategory}`));
      grid.appendChild(box);
    }
    s.appendChild(grid);
    formCol.appendChild(s);
  }

  // 字段定义（非末级 → 下级自动继承；末级 → 进物料档案）
  const s3 = mk('div', { class: 'section' });
  s3.appendChild(sectionTitle(++secIdx, '物料属性',
    cat.isLeaf
      ? '末级分组的字段：进入物料档案的列和新增/编辑表单，每个物料各自填值'
      : '定义一次，所有下级分组自动拥有，在各下级的分组管理里填值；不进物料档案'));

  // 属性集合：一套属性模板，套用后本组字段由集合实时提供
  let pendingDetach = false;
  const linkedSet = state.attrSets.find(s => s.id === cat.attrSetId) || null;
  const setRow = mk('div', { class: 'assign-row' });
  setRow.appendChild(mk('label', {}, '属性集合'));
  setRow.appendChild(infoTip(linkedSet
    ? `下表灰色行来自「${linkedSet.name}」，只读；要改请到「系统设置 → 属性集合」。白色行是本组额外字段。关联新集合会替换本组字段并清理已填的值（保存时会弹窗确认）。`
    : '关联集合会用集合字段替换本组现有字段，并清理这些字段已填的值（保存时会弹窗确认）。'));
  const setSelect = mk('select');
  setSelect.appendChild(mk('option', { value: '' }, '（不关联）'));
  for (const s of state.attrSets) {
    const o = mk('option', { value: s.id }, `${s.name}（${s.attrs.length} 个属性）`);
    if (cat.attrSetId === s.id) o.selected = true;
    setSelect.appendChild(o);
  }
  if (cat.attrSetId && !state.attrSets.some(s => s.id === cat.attrSetId)) {
    const o = mk('option', { value: cat.attrSetId }, '（集合已删除）');
    o.selected = true;
    setSelect.appendChild(o);
  }
  setRow.appendChild(setSelect);

  if (linkedSet) {
    setRow.appendChild(mk('span', { class: 'from-tag' }, '实时关联：改集合会影响所有关联分组'));
    const detachBtn = mk('button', { class: 'btn small', type: 'button' }, '脱离关联（复制一份）');
    detachBtn.addEventListener('click', () => {
      pendingDetach = true;
      setSelect.value = '';
      toast('已改为脱离：集合字段会复制为本组自有字段，点右侧 ✓ 保存后生效');
    });
    setRow.appendChild(detachBtn);
  }
  s3.appendChild(setRow);

  // 集合字段与本组自有字段放在同一张表里，集合行只读
  const attrTable = renderAttrDefTable(cat.attrs || [], state.dictionaries, linkedSet?.attrs || []);
  s3.appendChild(attrTable.root);
  formCol.appendChild(s3);

  // 统一保存：板块1 + 本级属性值 + 字段定义 一次存草稿
  const doSaveAll = async () => {
    const name = nameInput.value.trim();
    if (!name) { toastErr('名称必填'); return; }

    const setId = pendingDetach ? '' : (setSelect.value || '');
    const linking = !!setId && setId !== (cat.attrSetId || '');
    const linkedOf = linking ? state.attrSets.find(s => s.id === setId) : null;
    if (linking && !linkedOf) { toastErr('所选属性集合不存在'); return; }

    // 关联集合 = 用集合字段替换本组原有字段，并清理原有字段已填的值
    let removedKeys = [];
    let valuesInCats = 0;
    let matsAffected = 0;
    if (linking) {
      const setKeys = new Set((linkedOf.attrs || []).map(a => a.key));
      removedKeys = (cat.attrs || []).map(a => a.key).filter(k => !setKeys.has(k));
      const ids = Cat.selfAndDescendantIds(state.categories, cat.id);
      for (const c of state.categories) {
        if (!ids.has(c.id)) continue;
        for (const k of removedKeys) if (k in (c.attrValues || {})) valuesInCats++;
      }
      if (cat.isLeaf) {
        const summaries = state.materials.filter(m => m.categoryId === cat.id);
        const materials = await hydrateMaterials(summaries);
        for (const m of materials) {
          if (removedKeys.some(k => k in (m.attrs || {}))) matsAffected++;
        }
      }

      const ownCount = (cat.attrs || []).length;
      const lines = [
        `关联属性集合「${linkedOf.name}」会用集合字段替换本组现有字段。`,
        removedKeys.length
          ? `· 移除本组现有字段：${removedKeys.join('、')}`
          : (ownCount ? '· 本组自有字段与集合字段 key 相同，改由集合字段接管' : '· 本组当前没有自有字段'),
        valuesInCats ? `· 清理 ${valuesInCats} 处分组属性值（含下级分组）` : '',
        matsAffected ? `· 清理 ${matsAffected} 条物料的属性值` : '',
        removedKeys.length || valuesInCats || matsAffected ? '' : '· 没有已填的数据需要清理',
        '清理只在浏览器草稿里完成，提交前仍可在「提交管理」丢弃；提交后不可恢复。确定继续？',
      ].filter(Boolean);
      const ok = await confirm(lines.join('\n'), '⚠ 会替换字段并清理现有数据');
      if (!ok) { setSelect.value = cat.attrSetId || ''; return; }
    }

    let attrs;
    try { attrs = attrTable.read(); } catch (e) { toastErr(e.message); return; }

    // 脱离关联：把集合字段复制成本组自有字段（同名 key 本组覆盖）
    if (pendingDetach) {
      const merged = new Map();
      for (const a of attrsOf(cat)) merged.set(a.key, a);
      for (const a of attrs) merged.set(a.key, a);
      attrs = Array.from(merged.values());
    }
    // 关联集合：原有自有字段被集合字段替换
    if (linking) attrs = [];

    const keys = attrs.map(a => a.key);
    if (new Set(keys).size !== keys.length) { toastErr('属性 key 不能重复'); return; }

    // 本级属性值（直接父级定义的字段；整组一份，存本组 attrValues）
    const attrValues = { ...(cat.attrValues || {}) };
    if (ownForm) {
      const errs = ownForm.errors();
      if (errs.length) { toastErr('校验未通过：' + errs.join('；')); return; }
      const raw = ownForm.read();
      for (const def of parentDefs) {
        const v = raw[def.key];
        if (v === '' || v == null || (Array.isArray(v) && !v.length)
          || (def.type === 'range' && v.min === '' && v.max === '')) {
          delete attrValues[def.key];
        } else {
          attrValues[def.key] = v;
        }
      }
    }
    // 清掉已不属于任何生效字段的残留值
    const validKeys = new Set([...parentKeys, ...ancestorDefs.map(a => a.key), ...keys]);
    for (const k of Object.keys(attrValues)) if (!validKeys.has(k)) delete attrValues[k];

    if (!kids.length && cat.isLeaf && !leafChk.checked) {
      const count = state.materials.filter(m => m.categoryId === cat.id).length;
      if (count) { toastErr(`该分组下还有 ${count} 条物料，不能改为非末级`); return; }
    }

    const next = {
      ...cat,
      name,
      sort: Number(sortInput.value) || 0,
      desc: descInput.value.trim(),
      isLeaf: kids.length ? false : leafChk.checked,
      attrs,
      attrValues,
    };
    // 关联的属性集合（实时关联）；空值不写字段
    if (setId) next.attrSetId = setId;
    else delete next.attrSetId;
    delete next.code;
    const d = draftOf('category', cat.id);
    await saveCategoryDraft(next, d?.op === 'add' ? 'add' : 'update');

    // 关联后清理被移除字段在下级分组 / 物料上的残留值
    if (linking && removedKeys.length) await cleanFieldValues(cat, removedKeys);

    render();
    toastOk(linking ? '已关联集合并清理旧字段数据（草稿）' : '已保存为草稿');
  };

  // 右侧图标工具栏：保存 / 删除（样式同物料档案侧栏）
  const rail = mk('div', { class: 'side-rail' });
  const saveBtn = mk('button', { class: 'rail-btn', title: '保存' }, '✓');
  saveBtn.addEventListener('click', doSaveAll);
  rail.appendChild(saveBtn);
  rail.appendChild(mk('div', { class: 'rail-sep' }));
  const delBtn = mk('button', { class: 'rail-btn danger-hover', title: '删除分组' }, '✕');
  delBtn.addEventListener('click', () => doDeleteCategory(cat));
  rail.appendChild(delBtn);
  const copyBtn = mk('button', { class: 'rail-btn', title: '复制分组' }, '⧉');
  copyBtn.addEventListener('click', () => doCopyCategory(cat));
  rail.appendChild(copyBtn);

  body.appendChild(formCol);
  panel.appendChild(body);
  pendingRail = rail;   // 保存/删除/复制 挂到页面右栏
  return panel;
}

// 删除分组：有子分组或物料时不允许删；删除走草稿（提交管理可撤销）
async function doDeleteCategory(cat) {
  const kids = Cat.childIds(state.categories, cat.id);
  if (kids.length) { toastErr('该分组下还有子分组，请先删除或移走子分组'); return; }
  const matCount = state.materials.filter(m => m.categoryId === cat.id).length;
  if (matCount) { toastErr(`该分组下还有 ${matCount} 条物料，请先转移或删除这些物料`); return; }
  if (!(await confirm(`确定删除分组「${cat.name}」？`))) return;
  const d = draftOf('category', cat.id);
  if (d?.op === 'add') {
    await Store.removeDraft('category', cat.id);
    await loadDrafts();
  } else {
    await saveCategoryDraft({ ...cat }, 'delete');
  }
  render();
  toastOk('已标记为删除');
}

// 复制分组：可连同子分组一起复制，可选是否带上物料（全部走草稿）
async function doCopyCategory(cat) {
  const ids = Cat.selfAndDescendantIds(state.categories, cat.id);
  const subCount = ids.size - 1;
  const matsInTree = await hydrateMaterials(
    state.materials.filter(m => m.categoryId && ids.has(m.categoryId)));

  // 目标父级：根级 + 所有非末级分组（排除自身及后代，避免把树拷进自己里面）
  const parentOptions = [{ id: null, label: '（根级）' }];
  for (const c of state.categories) {
    if (ids.has(c.id) || c.isLeaf) continue;
    parentOptions.push({ id: c.id, label: Cat.categoryPathString(state.categories, c.id) });
  }

  const body = mk('div', { class: 'copy-form' });

  body.appendChild(mk('label', {}, '新分组名称'));
  const nameInput = mk('input', { type: 'text', value: `${cat.name} 副本` });
  body.appendChild(nameInput);

  body.appendChild(mk('label', {}, '复制到'));
  const parentSel = buildCategoryPicker(parentOptions, cat.parentId || '');
  body.appendChild(parentSel.el);

  body.appendChild(mk('label', {}, '复制内容'));
  const onlyChk = mk('input', { type: 'radio', name: 'copyMode', value: 'group', checked: true });
  const allChk = mk('input', { type: 'radio', name: 'copyMode', value: 'all' });
  const modeBox = mk('div', { class: 'copy-modes' });
  const mkMode = (input, text) => {
    const lbl = mk('label', { class: 'copy-mode' });
    lbl.appendChild(input);
    lbl.appendChild(mk('span', {}, text));
    return lbl;
  };
  modeBox.appendChild(mkMode(onlyChk, `仅分组数据（${subCount} 个子分组，不含物料）`));
  modeBox.appendChild(mkMode(allChk, `分组数据 + 物料档案（${subCount} 个子分组，${matsInTree.length} 条物料）`));
  if (!matsInTree.length) allChk.disabled = true;
  body.appendChild(modeBox);
  body.appendChild(mk('div', { class: 'hint' },
    '分组数据包含：名称、描述、排序、末级标记、属性字段与已填的整组属性值；物料会生成新的物料编码。'));

  openModal({
    title: `复制分组「${cat.name}」`,
    body,
    actions: [
      { label: '取消', onClick: closeModal },
      {
        label: '复制', className: 'primary',
        onClick: async () => {
          const name = nameInput.value.trim();
          if (!name) { toastErr('新分组名称必填'); return; }
          const targetParent = parentSel.value || null;
          if (state.categories.some(c => (c.parentId || null) === targetParent && c.name === name)) {
            toastErr('该层级下已有同名分组'); return;
          }

          // 1) 分组：先建新旧 id 映射，再按映射重建父子关系
          const idMap = new Map();
          for (const c of state.categories) if (ids.has(c.id)) idMap.set(c.id, mint('category'));
          const siblingCount = state.categories.filter(c => (c.parentId || null) === targetParent).length;

          const newCats = state.categories
            .filter(c => ids.has(c.id))
            .map(c => {
              const isRoot = c.id === cat.id;
              return {
                ...clone(c),
                id: idMap.get(c.id),
                name: isRoot ? name : c.name,
                parentId: isRoot ? targetParent : idMap.get(c.parentId || null),
                sort: isRoot ? siblingCount : c.sort,
                attrs: clone(c.attrs || []),
                attrValues: clone(c.attrValues || {}),
              };
            });
          for (const nc of newCats) await saveCategoryDraft(nc, 'add');

          // 2) 物料：先用临时编码，提交时统一分配正式编码
          let newMatCount = 0;
          if (allChk.checked && matsInTree.length) {
            for (const m of matsInTree) {
              const copyId = mint('m');
              await saveMaterialDraft({
                ...clone(m),
                id: copyId,
                categoryId: idMap.get(m.categoryId),
                code: tempCode(copyId),
                attrs: clone(m.attrs || {}),
                location: 'local',
                syncedAt: '',
                createdAt: nowISO(),
                updatedAt: nowISO(),
                createdBy: '',
                updatedBy: '',
              }, 'add');
              newMatCount++;
            }
          }

          await loadDrafts();
          closeModal();
          state.selectedCategoryId = idMap.get(cat.id);
          render();
          toastOk(`已复制为「${name}」（${newCats.length} 个分组${newMatCount ? `、${newMatCount} 条物料` : ''}，草稿）`);
        },
      },
    ],
  });
}


// 关联属性集合后，清理被移除字段在下级分组 / 本组物料上的残留值（全部走草稿）
async function cleanFieldValues(cat, removedKeys) {
  if (!removedKeys.length) return;
  const ids = Cat.selfAndDescendantIds(state.categories, cat.id);
  for (const c of state.categories) {
    if (!ids.has(c.id)) continue;
    const hit = removedKeys.filter(k => k in (c.attrValues || {}));
    if (!hit.length) continue;
    const next = { ...c, attrValues: { ...c.attrValues } };
    for (const k of hit) delete next.attrValues[k];
    const d = draftOf('category', c.id);
    await saveCategoryDraft(next, d?.op === 'add' ? 'add' : 'update');
  }
  // 只有末级分组的字段值存在物料上
  if (!cat.isLeaf) return;
  const materials = await hydrateMaterials(state.materials.filter(m => m.categoryId === cat.id));
  for (const m of materials) {
    const hit = removedKeys.filter(k => k in (m.attrs || {}));
    if (!hit.length) continue;
    const next = { ...m, attrs: { ...m.attrs }, updatedAt: nowISO() };
    for (const k of hit) delete next.attrs[k];
    const d = draftOf('material', m.id);
    await saveMaterialDraft(next, d?.op === 'add' ? 'add' : 'update');
  }
}

function sectionTitle(idx, text, sub) {
  const h = mk('div', { class: 'section-title' });
  h.appendChild(mk('span', { class: 'idx' }, String(idx)));
  h.appendChild(document.createTextNode(text));
  if (sub) h.appendChild(infoTip(sub));
  return h;
}

// 说明文字统一收进「!」图标，悬浮才显示，避免版面被小字提示占满
function infoTip(text) {
  return mk('span', { class: 'info-tip', 'data-tip': text, 'aria-label': text }, '!');
}

// 提示浮层挂在 body 上用 fixed 定位：面板是可滚动容器，放在里面会被裁剪
let _tipEl = null;

function bindInfoTips() {
  document.addEventListener('mouseover', (e) => {
    const icon = e.target.closest && e.target.closest('.info-tip');
    if (icon) showInfoTip(icon);
  });
  document.addEventListener('mouseout', (e) => {
    if (e.target.closest && e.target.closest('.info-tip')) hideInfoTip();
  });
  window.addEventListener('scroll', hideInfoTip, true);
  window.addEventListener('resize', hideInfoTip);
}

// 全项目通用：任何被省略号截断的文本（表格单元格、分组名、导航名）悬停显示全文
function bindTruncatedTips() {
  const SEL = 'td, th, .tree-label, .nav-label';
  const skip = (e) => e.target.closest && e.target.closest('input, textarea, [contenteditable="true"]');
  document.addEventListener('mouseover', (e) => {
    if (skip(e)) return;
    const el = e.target.closest && e.target.closest(SEL);
    if (!el) return;
    if (e.relatedTarget instanceof Element && el.contains(e.relatedTarget)) return;
    if (!isTextTruncated(el)) { hideHoverTip(); return; }
    showHoverTip(el, (el.textContent || '').trim());
  });
  document.addEventListener('mouseout', (e) => {
    const el = e.target.closest && e.target.closest(SEL);
    if (!el) return;
    if (e.relatedTarget instanceof Element && el.contains(e.relatedTarget)) return;
    hideHoverTip();
  });
}

function showInfoTip(icon) {
  hideInfoTip();
  const text = icon.getAttribute('data-tip');
  if (!text) return;
  const el = mk('div', { class: 'info-tip-pop' }, text);
  document.body.appendChild(el);

  const pad = 8;
  const r = icon.getBoundingClientRect();
  const w = el.offsetWidth;
  const h = el.offsetHeight;
  // 水平居中在图标下方，超出视口就夹紧
  let left = r.left + r.width / 2 - w / 2;
  left = Math.max(pad, Math.min(left, window.innerWidth - w - pad));
  // 下方放不下就翻到上方
  let top = r.bottom + 6;
  if (top + h > window.innerHeight - pad) top = Math.max(pad, r.top - h - 6);

  el.style.left = `${left}px`;
  el.style.top = `${top}px`;
  _tipEl = el;
}

function hideInfoTip() {
  if (_tipEl) { _tipEl.remove(); _tipEl = null; }
}

function fieldBox(label, input) {
  const wrap = mk('div', { class: 'field' });
  wrap.appendChild(mk('label', {}, label));
  wrap.appendChild(input);
  return wrap;
}

// ---------- 分组新建 ----------
function openCategoryDialog(parentId) {
  const body = mk('div');
  const nameInput = mk('input', { type: 'text', placeholder: '分组名称，如 成品' });

  const grid = mk('div', { class: 'form-grid' });
  const nameBox = fieldBox('名称', nameInput);
  nameBox.classList.add('full');
  grid.appendChild(nameBox);
  body.appendChild(grid);

  if (parentId) {
    body.appendChild(mk('div', { class: 'muted', style: 'margin-top:10px;font-size:12px;' },
      '父级：' + Cat.categoryPathString(state.categories, parentId)));
  }

  openModal({
    title: parentId ? '新建子分组' : '新建分组',
    body,
    actions: [
      { label: '取消', onClick: closeModal },
      {
        label: '创建', className: 'primary',
        onClick: async () => {
          const name = nameInput.value.trim();
          if (!name) { toastErr('名称必填'); return; }
          // 同级不允许重名，避免误建出多个同名分组
          if (state.categories.some(c => (c.parentId || null) === (parentId || null) && c.name === name)) {
            toastErr(`同级下已存在「${name}」`);
            return;
          }
          // 新分组排在同级最下面，默认非末级（末级在「分组管理」里勾选）
          const siblingCount = state.categories.filter(c => (c.parentId ?? null) === (parentId ?? null)).length;
          const cat = Cat.makeCategory(() => mint('c'), {
            name, parentId: parentId || null, sort: siblingCount,
          });
          await saveCategoryDraft(cat, 'add');
          // 父级不再是末级
          if (parentId) {
            const parent = Cat.findCategory(state.categories, parentId);
            if (parent) {
              await saveCategoryDraft({ ...parent, isLeaf: false }, draftOf('category', parentId)?.op === 'add' ? 'add' : 'update');
            }
            state.expanded.add(parentId);
          }
          state.selectedCategoryId = cat.id;
          state.activeTab = 'manage';
          closeModal();
          render();
          toastOk('分组已创建（草稿）');
        },
      },
    ],
  });
}

// ---------- 系统设置：字典设置 + 属性集合 ----------
function renderSettings() {
  const content = document.getElementById('content');
  content.className = 'content setting-page';
  content.innerHTML = '';

  if (!state.settingTab) state.settingTab = 'dict';
  pendingRail = null;
  const titles = { dict: '字典设置', set: '属性集合', menu: '菜单管理' };
  const tips = {
    dict: '字典是给「下拉单选 / 单选 / 多选」类型属性提供选项的选项库，改一次所有引用它的字段一起生效。',
    set: '属性集合是一整套属性模板：在分组管理里「关联」后，该分组的物料属性由集合实时提供，改集合一次全部生效。',
    menu: '内置菜单由系统提供，不能删除，但可以调整顺序、显隐、名称与图标；自定义菜单可以指向站内页面或外部网址。改动先存为草稿，提交后写入 data/menu.json。',
  };
  const builders = { dict: buildDictionarySection, set: buildAttrSetSection, menu: buildMenuSection };
  const tab = state.settingTab;
  const block = (builders[tab] || buildDictionarySection)();
  const titleRow = mk('div', { class: 'setting-title-row' });
  titleRow.appendChild(mk('div', { class: 'setting-title' }, titles[tab] || '字典设置'));
  titleRow.appendChild(infoTip(tips[tab] || ''));
  block.insertBefore(titleRow, block.firstChild);
  content.appendChild(block);
  if (pendingRail) content.appendChild(pendingRail);   // 右栏：图标工具栏
}

// ----- 字典设置 -----
function buildDictionarySection() {
  const wrap = mk('div', { class: 'setting-block' });

  const bar = mk('div', { class: 'toolbar' });
  const search = mk('input', { type: 'search', placeholder: '搜索字典名称 / 选项' });
  search.value = state.dictSearch || '';
  bar.appendChild(search);
  const info = mk('span', { class: 'hint' });
  bar.appendChild(info);
  wrap.appendChild(bar);

  const tableWrap = mk('div', { class: 'table-wrap' });
  wrap.appendChild(tableWrap);

  const selected = () => Array.from(state.dictChecked)
    .map(id => state.dictionaries.find(d => d.id === id)).filter(Boolean);

  pendingRail = buildSettingRail({
    label: '字典',
    count: state.dictChecked.size,
    onNew: () => openDictionaryDialog(null),
    onEdit: () => openDictionaryDialog(selected()[0]),
    onCopy: () => doCopyDictionary(selected()[0]),
    onDelete: () => doDeleteDictionary(selected()[0], dictUsedBy(selected()[0])),
  });

  const renderTable = () => {
    const kw = (state.dictSearch || '').trim().toLowerCase();
    const list = state.dictionaries.filter(d => !kw || d.name.toLowerCase().includes(kw)
      || (d.items || []).some(i => `${i.label} ${i.value}`.toLowerCase().includes(kw)));
    tableWrap.innerHTML = '';
    info.textContent = `共 ${list.length} 个`;
    if (!list.length) {
      tableWrap.appendChild(mk('div', { class: 'empty', style: 'padding:24px;' },
        kw ? '没有匹配的字典' : '还没有字典'));
      return;
    }

    const table = mk('table', { class: 'grid' });
    const head = mk('tr');
    ['', '字典名称', '选项数', '选项预览', '被引用', '操作'].forEach((t, i) => {
      const th = mk('th', {}, t);
      if (i === 5) th.className = 'col-ops';
      head.appendChild(th);
    });
    table.appendChild(head);

    for (const dict of list) {
      const usedBy = dictUsedBy(dict);
      const tr = mk('tr');
      const cb = mk('input', { type: 'checkbox' });
      cb.checked = state.dictChecked.has(dict.id);
      cb.addEventListener('change', () => {
        state.dictChecked.delete(dict.id);
        if (cb.checked) state.dictChecked.add(dict.id);
        render();
      });
      const chkTd = mk('td');
      chkTd.appendChild(cb);
      tr.appendChild(chkTd);
      tr.appendChild(mk('td', { class: 'plain' }, dict.name));
      tr.appendChild(mk('td', {}, String((dict.items || []).length)));
      tr.appendChild(mk('td', { class: 'wrap' }, (dict.items || []).map(i => i.label).join('、') || '—'));
      tr.appendChild(mk('td', {}, usedBy.length ? `${usedBy.length} 个字段` : '—'));

      const ops = mk('td', { class: 'col-ops' });
      const edit = mk('button', { class: 'link-btn' }, '编辑');
      edit.addEventListener('click', () => openDictionaryDialog(dict));
      const del = mk('button', { class: 'link-btn danger' }, '删除');
      del.addEventListener('click', () => doDeleteDictionary(dict, usedBy));
      ops.appendChild(edit);
      ops.appendChild(del);
      tr.appendChild(ops);
      table.appendChild(tr);
    }
    tableWrap.appendChild(table);
  };

  search.addEventListener('input', () => { state.dictSearch = search.value; renderTable(); });
  renderTable();
  return wrap;
}

// 设置类页面右侧操作栏：新建 / 编辑 / 复制 / 删除（后三项需选中 1 项）
// 传 onUp/onDown 时改为「新建 / 上移 / 下移 / 删除」，用于菜单管理这类需要排序的列表
function buildSettingRail({ label, count, onNew, onEdit, onCopy, onUp, onDown, onDelete }) {
  const rail = mk('div', { class: 'side-rail' });
  const sep = () => mk('div', { class: 'rail-sep' });
  const one = count === 1;

  const add = mk('button', { class: 'rail-btn', title: `新建${label}` }, '＋');
  add.addEventListener('click', onNew);

  const del = mk('button', { class: 'rail-btn danger-hover', title: `删除${label}（先勾选 1 项）` }, '✕');
  del.disabled = !one;
  del.addEventListener('click', onDelete);

  rail.appendChild(add);
  rail.appendChild(sep());

  if (onUp || onDown) {
    const up = mk('button', { class: 'rail-btn', title: `上移${label}（先勾选 1 项）` }, '↑');
    up.disabled = !one;
    up.addEventListener('click', onUp);
    const down = mk('button', { class: 'rail-btn', title: `下移${label}（先勾选 1 项）` }, '↓');
    down.disabled = !one;
    down.addEventListener('click', onDown);
    rail.appendChild(up);
    rail.appendChild(down);
  } else {
    const edit = mk('button', { class: 'rail-btn', title: `编辑${label}（先勾选 1 项）` }, '✎');
    edit.disabled = !one;
    edit.addEventListener('click', onEdit);
    rail.appendChild(edit);
    if (onCopy) {
      const copy = mk('button', { class: 'rail-btn', title: `复制${label}（先勾选 1 项）` }, '⧉');
      copy.disabled = !one;
      copy.addEventListener('click', onCopy);
      rail.appendChild(copy);
    }
  }

  rail.appendChild(sep());
  rail.appendChild(del);
  return rail;
}

// 复制字典：名称加「（副本）」，选项深拷贝
async function doCopyDictionary(src) {
  if (!src) return;
  let name = `${src.name} 副本`;
  let i = 2;
  while (state.dictionaries.some(d => d.name === name)) name = `${src.name} 副本${i++}`;
  const id = mint('dict');
  await saveDictionaryDraft({
    id,
    name,
    items: (src.items || []).map(x => ({ ...x })),
  }, 'add');
  state.dictChecked = new Set([id]);
  render();
  toastOk(`已复制为「${name}」`);
}

// 复制属性集合：名称加「（副本）」，属性定义深拷贝
async function doCopyAttrSet(src) {
  if (!src) return;
  let name = `${src.name} 副本`;
  let i = 2;
  while (state.attrSets.some(s => s.name === name)) name = `${src.name} 副本${i++}`;
  const id = mint('set');
  await saveAttrSetDraft({
    id,
    name,
    attrs: (src.attrs || []).map(a => ({ ...a })),
  }, 'add');
  state.setChecked = new Set([id]);
  render();
  toastOk(`已复制为「${name}」`);
}

// 字典被哪些字段引用（分组自有字段 + 属性集合字段）
function dictUsedBy(dict) {
  return [
    ...state.categories.flatMap(c => (c.attrs || []).map(a => ({ a, c }))),
    ...state.attrSets.flatMap(s => (s.attrs || []).map(a => ({ a, c: { name: '集合：' + s.name } }))),
  ].filter(x => x.a.dictId === dict.id);
}

// 字典编辑弹窗；dict 传 null 为新建
function openDictionaryDialog(dict) {
  const cur = dict
    ? { id: dict.id, name: dict.name, items: (dict.items || []).map(i => ({ ...i })) }
    : { id: mint('dict'), name: '', items: [] };

  const body = mk('div');
  const grid = mk('div', { class: 'form-grid' });
  const nameInput = mk('input', { type: 'text', value: cur.name, placeholder: '字典名称，如 标称截面' });
  const nameBox = fieldBox('字典名称', nameInput);
  nameBox.classList.add('full');
  nameBox.appendChild(mk('div', { class: 'hint' },
    '显示名给用户看，存储值写进数据（留空则与显示名相同）'));
  grid.appendChild(nameBox);
  body.appendChild(grid);

  const itemWrap = mk('div', { class: 'dict-items', style: 'margin-top:16px;' });
  const head = mk('div', { class: 'dict-item-row dict-item-head' });
  head.appendChild(mk('span', { class: 'muted' }, '显示名'));
  head.appendChild(mk('span', { class: 'muted' }, '存储值'));
  head.appendChild(mk('span', {}));
  itemWrap.appendChild(head);

  const rows = [];
  const addItemRow = (item) => {
    const row = mk('div', { class: 'dict-item-row' });
    const labelInput = mk('input', { type: 'text', value: item?.label || '', placeholder: '显示名，如 35平方' });
    const valueInput = mk('input', { type: 'text', value: item?.value || '', placeholder: '存储值，如 35' });
    const rm = mk('button', { class: 'btn danger small', type: 'button' }, '删');
    rm.addEventListener('click', () => { row.remove(); });
    row.appendChild(labelInput);
    row.appendChild(valueInput);
    row.appendChild(rm);
    itemWrap.appendChild(row);
    rows.push({ row, labelInput, valueInput });
  };
  for (const it of cur.items) addItemRow(it);
  body.appendChild(itemWrap);

  const addBtn = mk('button', { class: 'btn small', type: 'button', style: 'margin-top:8px;' }, '＋ 添加选项');
  addBtn.addEventListener('click', () => addItemRow({ label: '', value: '' }));
  body.appendChild(addBtn);

  openModal({
    title: dict ? `编辑字典「${dict.name}」` : '新建字典',
    body,
    actions: [
      { label: '取消', onClick: closeModal },
      {
        label: '保存',
        className: 'primary',
        onClick: async () => {
          const name = nameInput.value.trim();
          if (!name) { toastErr('字典名称必填'); return; }
          if (state.dictionaries.some(d => d.id !== cur.id && d.name === name)) {
            toastErr('字典名称已存在'); return;
          }
          const items = [];
          for (const r of rows) {
            if (!r.row.isConnected) continue;
            const label = r.labelInput.value.trim();
            const value = r.valueInput.value.trim();
            if (!label && !value) continue;
            if (!value) { toastErr('存储值不能为空'); return; }
            if (items.some(i => i.value === value)) { toastErr(`存储值「${value}」重复`); return; }
            items.push({ value, label: label || value });
          }
          const d = draftOf('dictionary', cur.id);
          await saveDictionaryDraft({ id: cur.id, name, items },
            (!dict || d?.op === 'add') ? 'add' : 'update');
          closeModal();
          render();
          toastOk('字典已保存为草稿');
        },
      },
    ],
  });
}

async function doDeleteDictionary(dict, usedBy) {
  if (!dict) return;
  if (usedBy.length) {
    const where = usedBy.slice(0, 5).map(x => `「${x.c.name}」的「${x.a.label}」`).join('、');
    toastErr(`该字典正被 ${usedBy.length} 个字段引用（${where}${usedBy.length > 5 ? ' 等' : ''}），请先改成其它字典`);
    return;
  }
  if (!(await confirm(`确定删除字典「${dict.name}」？`))) return;
  const d = draftOf('dictionary', dict.id);
  if (d?.op === 'add') {
    await Store.removeDraft('dictionary', dict.id);
    await loadDrafts();
  } else {
    await saveDictionaryDraft({ ...dict }, 'delete');
  }
  render();
  toastOk('已标记为删除');
}

// ----- 属性集合 -----
function buildAttrSetSection() {
  const wrap = mk('div', { class: 'setting-block' });

  const bar = mk('div', { class: 'toolbar' });
  const search = mk('input', { type: 'search', placeholder: '搜索集合名称 / 属性' });
  search.value = state.setSearch || '';
  bar.appendChild(search);
  const info = mk('span', { class: 'hint' });
  bar.appendChild(info);
  wrap.appendChild(bar);

  const tableWrap = mk('div', { class: 'table-wrap' });
  wrap.appendChild(tableWrap);

  const selected = () => Array.from(state.setChecked)
    .map(id => state.attrSets.find(s => s.id === id)).filter(Boolean);
  const usedByOf = (set) => state.categories.filter(c => c.attrSetId === set.id);

  pendingRail = buildSettingRail({
    label: '属性集合',
    count: state.setChecked.size,
    onNew: () => openAttrSetDialog(null),
    onEdit: () => openAttrSetDialog(selected()[0]),
    onCopy: () => doCopyAttrSet(selected()[0]),
    onDelete: () => doDeleteAttrSet(selected()[0], usedByOf(selected()[0])),
  });

  const renderTable = () => {
    const kw = (state.setSearch || '').trim().toLowerCase();
    const list = state.attrSets.filter(s => !kw || s.name.toLowerCase().includes(kw)
      || (s.attrs || []).some(a => `${a.label} ${a.key}`.toLowerCase().includes(kw)));
    tableWrap.innerHTML = '';
    info.textContent = `共 ${list.length} 个`;
    if (!list.length) {
      tableWrap.appendChild(mk('div', { class: 'empty', style: 'padding:24px;' },
        kw ? '没有匹配的属性集合' : '还没有属性集合'));
      return;
    }

    const table = mk('table', { class: 'grid' });
    const head = mk('tr');
    ['', '集合名称', '属性数', '属性预览', '使用分组', '操作'].forEach((t, i) => {
      const th = mk('th', {}, t);
      if (i === 5) th.className = 'col-ops';
      head.appendChild(th);
    });
    table.appendChild(head);

    for (const set of list) {
      const usedBy = usedByOf(set);
      const tr = mk('tr');
      const cb = mk('input', { type: 'checkbox' });
      cb.checked = state.setChecked.has(set.id);
      cb.addEventListener('change', () => {
        state.setChecked.delete(set.id);
        if (cb.checked) state.setChecked.add(set.id);
        render();
      });
      const chkTd = mk('td');
      chkTd.appendChild(cb);
      tr.appendChild(chkTd);
      tr.appendChild(mk('td', { class: 'plain' }, set.name));
      tr.appendChild(mk('td', {}, String((set.attrs || []).length)));
      tr.appendChild(mk('td', { class: 'wrap' }, (set.attrs || []).map(a => a.label).join('、') || '—'));
      tr.appendChild(mk('td', {}, usedBy.length ? `${usedBy.length} 个分组` : '—'));

      const ops = mk('td', { class: 'col-ops' });
      const edit = mk('button', { class: 'link-btn' }, '编辑');
      edit.addEventListener('click', () => openAttrSetDialog(set));
      const del = mk('button', { class: 'link-btn danger' }, '删除');
      del.addEventListener('click', () => doDeleteAttrSet(set, usedBy));
      ops.appendChild(edit);
      ops.appendChild(del);
      tr.appendChild(ops);
      table.appendChild(tr);
    }
    tableWrap.appendChild(table);
  };

  search.addEventListener('input', () => { state.setSearch = search.value; renderTable(); });
  renderTable();
  return wrap;
}

// 属性集合编辑弹窗；set 传 null 为新建
function openAttrSetDialog(set) {
  const cur = set
    ? { id: set.id, name: set.name, attrs: (set.attrs || []).map(a => ({ ...a })) }
    : { id: mint('set'), name: '', attrs: [] };

  const body = mk('div');
  const grid = mk('div', { class: 'form-grid' });
  const nameInput = mk('input', { type: 'text', value: cur.name, placeholder: '集合名称，如 电缆通用属性' });
  const nameBox = fieldBox('集合名称', nameInput);
  nameBox.classList.add('full');
  grid.appendChild(nameBox);
  body.appendChild(grid);

  const editor = renderAttrDefTable(cur.attrs, state.dictionaries);
  editor.root.style.marginTop = '16px';
  body.appendChild(editor.root);

  openModal({
    title: set ? `编辑属性集合「${set.name}」` : '新建属性集合',
    body,
    actions: [
      { label: '取消', onClick: closeModal },
      {
        label: '保存',
        className: 'primary',
        onClick: async () => {
          const name = nameInput.value.trim();
          if (!name) { toastErr('集合名称必填'); return; }
          if (state.attrSets.some(s => s.id !== cur.id && s.name === name)) {
            toastErr('集合名称已存在'); return;
          }
          let attrs;
          try { attrs = editor.read(); } catch (e) { toastErr(e.message); return; }
          const keys = attrs.map(a => a.key);
          if (new Set(keys).size !== keys.length) { toastErr('属性 key 不能重复'); return; }
          const d = draftOf('attrSet', cur.id);
          await saveAttrSetDraft({ id: cur.id, name, attrs },
            (!set || d?.op === 'add') ? 'add' : 'update');
          closeModal();
          render();
          toastOk('属性集合已保存为草稿');
        },
      },
    ],
  });
}

async function doDeleteAttrSet(set, usedBy) {
  if (!set) return;
  if (usedBy.length) {
    toastErr(`该集合正被 ${usedBy.length} 个分组关联（${usedBy.slice(0, 3).map(c => '「' + c.name + '」').join('、')}${usedBy.length > 3 ? ' 等' : ''}），请先在这些分组里取消关联或脱离关联`);
    return;
  }
  if (!(await confirm(`确定删除属性集合「${set.name}」？`))) return;
  const d = draftOf('attrSet', set.id);
  if (d?.op === 'add') {
    await Store.removeDraft('attrSet', set.id);
    await loadDrafts();
  } else {
    await saveAttrSetDraft({ ...set }, 'delete');
  }
  render();
  toastOk('已标记为删除');
}

// ---------- 提交管理 ----------
function renderCommit() {  const content = document.getElementById('content');
  content.className = 'content scroll';
  content.innerHTML = '';

  const titleRow = mk('div', { class: 'setting-title-row', style: 'margin-bottom:16px' });
  titleRow.appendChild(mk('div', { class: 'setting-title' }, '提交管理'));
  titleRow.appendChild(infoTip('所有改动先暂存在浏览器（IndexedDB），勾选后一次性提交到数据仓库；提交成功后自动清空已提交的草稿。'));
  content.appendChild(titleRow);

  // 当前账号与数据仓库
  const repoSection = mk('div', { class: 'section' });
  repoSection.appendChild(mk('div', { class: 'section-title' }, '数据仓库'));
  const repoCard = mk('div', { class: 'repo-summary' });
  repoCard.appendChild(mk('div', { class: 'repo-summary-name' }, `${state.settings.owner}/${state.settings.repo}`));
  repoCard.appendChild(mk('div', { class: 'repo-summary-meta' },
    `分支 ${state.settings.branch} · 登录账号 ${state.user?.login || '—'}`));
  repoSection.appendChild(repoCard);

  repoSection.appendChild(mk('div', { class: 'hint', style: 'margin-top:8px;font-size:12px;color:var(--text-muted);' },
    '数据只写入该仓库；PAT 保存在本机浏览器，退出登录会一并清除。'));
  content.appendChild(repoSection);

  // 首次进入空仓库：初始化基础文件，进入提交管理统一提交
  let initChk = null;
  if (state.missingDataFiles.length) {
    const initSection = mk('div', { class: 'section' });
    initSection.appendChild(mk('div', { class: 'section-title' }, '仓库初始化'));
    const row = mk('label', { class: 'checkbox-label' });
    initChk = mk('input', { type: 'checkbox' });
    initChk.checked = true;
    row.appendChild(initChk);
    row.appendChild(document.createTextNode(` 创建 ${state.missingDataFiles.length} 个基础数据文件`));
    initSection.appendChild(row);
    initSection.appendChild(mk('div', { class: 'hint', style: 'margin-top:6px;font-size:12px;color:var(--text-muted);' },
      state.missingDataFiles.join('、')));
    content.appendChild(initSection);
  }

  // 改动列表
  const listSection = mk('div', { class: 'section' });
  listSection.appendChild(mk('div', { class: 'section-title' }, `待提交改动（${state.drafts.length}）`));
  const checkboxes = [];

  if (!state.drafts.length) {
    listSection.appendChild(mk('div', { class: 'empty', style: 'padding:24px;' },
      state.missingDataFiles.length ? '暂无草稿改动，仅需初始化仓库' : '暂无待提交改动'));
  } else {
    const selAllRow = mk('label', { class: 'checkbox-label', style: 'margin-bottom:6px;' });
    const selAll = mk('input', { type: 'checkbox' });
    selAll.checked = true;
    selAllRow.appendChild(selAll);
    selAllRow.appendChild(document.createTextNode(' 全选'));
    listSection.appendChild(selAllRow);

    const ul = mk('ul', { class: 'commit-list' });
    for (const d of state.drafts) {
      const li = mk('li');
      const chk = mk('input', { type: 'checkbox' });
      chk.checked = true;
      chk.dataset.id = d.id;
      checkboxes.push(chk);
      li.appendChild(chk);
      li.appendChild(mk('span', {}, draftLabel(d)));
      ul.appendChild(li);
    }
    listSection.appendChild(ul);

    selAll.addEventListener('change', () => checkboxes.forEach(c => { c.checked = selAll.checked; }));
  }

  const hasWork = state.drafts.length > 0 || !!initChk;
  if (hasWork) {
    const msgInput = mk('input', {
      type: 'text',
      placeholder: '提交说明（留空自动生成）',
      style: 'width:100%;padding:6px 10px;border:1px solid var(--border-strong);border-radius:6px;margin-top:12px;',
    });
    listSection.appendChild(msgInput);

    const actionRow = mk('div', { style: 'display:flex;align-items:center;gap:12px;margin-top:12px;' });
    const btn = mk('button', { class: 'btn primary' }, '提交选中项到数据仓库');
    btn.addEventListener('click', () => {
      const ids = checkboxes.filter(c => c.checked).map(c => c.dataset.id);
      const includeInit = !!initChk?.checked;
      if (!ids.length && !includeInit) { toastErr('请勾选至少一项'); return; }
      doCommit(ids, msgInput.value.trim(), btn, includeInit);
    });
    const discard = mk('button', { class: 'btn danger', style: 'margin-left:auto;' }, '丢弃全部草稿');
    discard.disabled = !state.drafts.length;
    discard.addEventListener('click', discardAllDrafts);
    actionRow.append(btn, discard);
    listSection.appendChild(actionRow);
  }
  content.appendChild(listSection);

  // 维护：修复「分片有物料、搜索索引为空」导致全部物料显示 0 条
  const maintainSection = mk('div', { class: 'section' });
  maintainSection.appendChild(mk('div', { class: 'section-title' }, '维护'));
  const rebuildBtn = mk('button', { class: 'btn' }, '重建搜索索引');
  rebuildBtn.addEventListener('click', () => rebuildSearchIndex(rebuildBtn));
  maintainSection.appendChild(rebuildBtn);
  maintainSection.appendChild(mk('div', {
    class: 'hint',
    style: 'margin-top:6px;font-size:12px;color:var(--text-muted);',
  }, '扫描所有分组的分片并重写 search-index.json.gz 与 manifest.json；用于物料档案有数据但「全部物料」显示 0 条的情况。'));
  content.appendChild(maintainSection);
}

async function rebuildSearchIndex(btn) {
  if (!(await confirm('将扫描所有分组的分片并重建全局搜索索引，继续？'))) return;
  btn.disabled = true;
  progressStart('扫描分组数据…');
  try {
    const ids = ['', ...state.categories.map(c => c.id)];
    const payload = await MaterialStore.rebuildSearchIndex(ids, (done, total) => progressSet(done, total, '扫描分组'));
    if (!payload.total) { toastErr('分片里没有找到任何物料'); return; }
    progressStart('写入搜索索引…');
    const result = await GH.singleCommit({
      message: 'chore: 重建搜索索引',
      baseCommit: state.remoteHead,
      treeChanges: payload.fileChanges,
      treeDeletes: payload.treeDeletes,
    });
    await applyCommittedPayload(payload, result.commitSha);
    toastOk(`已重建搜索索引（${payload.total} 条）`);
    render();
  } catch (e) {
    toastErr(e.message || '重建失败');
  } finally {
    progressEnd();
    btn.disabled = false;
  }
}

// ---------- 系统设置：菜单管理 ----------
// 内置菜单写在代码里，data/menu.json 只记录顺序、显隐、名称、图标与自定义项
async function saveMenuConfig(next, { rerender = false } = {}) {
  const normalized = normalizeMenu(next);
  const base = normalizeMenu(state.baseMenu || defaultMenuConfig());
  if (JSON.stringify(normalized) === JSON.stringify(base)) {
    // 与远端一致就不留草稿，避免提交管理里出现空改动
    await Store.removeDraft('menu', 'nav');
  } else {
    await Store.putDraft({
      id: 'menu:nav',
      kind: 'menu',
      recordId: 'nav',
      op: 'update',
      data: clone(normalized),
    });
  }
  await loadDrafts();
  renderNav();
  if (rerender) render();
}

async function updateMenuOverride(key, patch) {
  const next = clone(state.menu);
  const cur = { ...(next.overrides[key] || {}), ...patch };
  for (const k of Object.keys(cur)) if (cur[k] === undefined || cur[k] === '') delete cur[k];
  if (Object.keys(cur).length) next.overrides[key] = cur;
  else delete next.overrides[key];
  await saveMenuConfig(next, { rerender: true });
}

// 菜单所在的上级：空串 = 一级导航
function findMenuParent(menu, key) {
  if (menu.order.includes(key)) return '';
  return Object.keys(menu.children).find(p => menu.children[p].includes(key)) || '';
}

function detachMenuKey(menu, key) {
  menu.order = menu.order.filter(k => k !== key);
  for (const parent of Object.keys(menu.children)) {
    menu.children[parent] = menu.children[parent].filter(k => k !== key);
  }
}

function appendMenuKey(menu, key, parent) {
  if (!parent) menu.order.push(key);
  else (menu.children[parent] = menu.children[parent] || []).push(key);
}

async function moveMenuKey(key, delta, parent) {
  const next = clone(state.menu);
  const list = parent === '' ? next.order : next.children[parent];
  if (!list) return;
  const i = list.indexOf(key);
  const j = i + delta;
  if (i < 0 || j < 0 || j >= list.length) return;
  [list[i], list[j]] = [list[j], list[i]];
  await saveMenuConfig(next, { rerender: true });
}

async function removeCustomMenu(id) {
  const custom = state.menu.custom.find(c => c.id === id);
  if (!custom) { toastErr('内置菜单不能删除，只能隐藏'); return; }
  if (!(await confirm(`删除自定义菜单「${custom.label || '未命名'}」？`, '删除菜单'))) return;
  const next = clone(state.menu);
  next.custom = next.custom.filter(c => c.id !== id);
  next.order = next.order.filter(k => k !== id);
  for (const parent of Object.keys(next.children)) {
    next.children[parent] = next.children[parent].filter(k => k !== id);
  }
  delete next.overrides[id];
  state.menuChecked.delete(id);
  await saveMenuConfig(next, { rerender: true });
  toastOk('已删除菜单（草稿）');
}

async function resetMenuConfig() {
  if (!(await confirm('恢复默认菜单？当前的顺序、显隐、名称、图标与自定义菜单都会被撤销。'))) return;
  state.menuChecked.clear();
  await saveMenuConfig(defaultMenuConfig(), { rerender: true });
  toastOk('已恢复默认菜单');
}

// 新增 / 编辑菜单共用一个弹窗，字段固定：名称 / 上级菜单 / 图标 / 地址 / 打开方式 / 显示
// 内置菜单的上级、地址、打开方式固定不可改；子菜单没有图标；菜单管理自身不能隐藏
function openMenuDialog(key = null) {
  const isNew = !key;
  const builtinParent = key && NAV_BUILTINS[key] ? 'main'
    : key && NAV_BUILTINS.settings.children[key] ? 'child' : null;
  const builtin = builtinParent === 'child' ? NAV_BUILTINS.settings.children[key]
    : builtinParent === 'main' ? NAV_BUILTINS[key] : null;
  const custom = key ? state.menu.custom.find(c => c.id === key) : null;

  // 层级：1 一级、2 二级、3 三级；自定义菜单可以挂到任意未满三级的菜单下
  const levelOf = (id) => {
    let level = 1;
    const guard = new Set([id]);
    let p = findMenuParent(state.menu, id);
    while (p && !guard.has(p)) { guard.add(p); level += 1; p = findMenuParent(state.menu, p); }
    return level;
  };
  const subtreeHeight = (id) => 1 + Math.max(0, ...(state.menu.children[id] || []).map(subtreeHeight));
  const isDescendant = (candidate, ancestor) =>
    (state.menu.children[ancestor] || []).some(k => k === candidate || isDescendant(candidate, k));
  const currentParent = key ? findMenuParent(state.menu, key) : '';
  const initialParent = builtinParent === 'child' ? 'settings' : builtinParent === 'main' ? '' : currentParent;
  let icon = custom?.icon || builtin?.icon || '↗';

  const body = mk('div', { class: 'menu-form' });
  const addRow = (label, ...nodes) => {
    const row = mk('div', { class: 'menu-form-row' });
    row.appendChild(mk('span', { class: 'menu-form-label' }, label));
    nodes.forEach(n => row.appendChild(n));
    body.appendChild(row);
    return row;
  };

  const nameInput = mk('input', { type: 'text', placeholder: '菜单名称，如「帮助文档」', maxLength: 12 });
  nameInput.value = isNew ? '' : (custom ? custom.label : menuLabel(key));
  addRow('名称', nameInput);

  // 上级菜单：内置菜单固定；自定义菜单最多挂到三级
  const parentSelect = mk('select');
  parentSelect.appendChild(mk('option', { value: '' }, '主导航'));
  parentSelect.appendChild(mk('option', { value: 'settings' }, '系统设置'));
  const selfHeight = key ? subtreeHeight(key) : 1;
  for (const item of state.menu.custom) {
    if (!item.id || item.id === key) continue;
    if (key && isDescendant(item.id, key)) continue;
    if (item.id !== currentParent && levelOf(item.id) + selfHeight > 3) continue;
    parentSelect.appendChild(mk('option', { value: item.id }, item.label || '未命名'));
  }
  // 当前上级一定要在下拉里，否则编辑时会显示空白
  if (currentParent && ![currentParent, 'settings'].includes(currentParent)
    && !Array.from(parentSelect.options).some(o => o.value === currentParent)) {
    parentSelect.appendChild(mk('option', { value: currentParent }, menuLabel(currentParent)));
  }
  parentSelect.value = initialParent;
  parentSelect.disabled = !!builtin;
  addRow('上级菜单', parentSelect);

  // 图标：子菜单在导航里不显示图标，禁用但保持同一布局
  const iconGrid = mk('div', { class: 'icon-picker-grid' });
  const paintGrid = () => iconGrid.querySelectorAll('.icon-picker-item')
    .forEach(b => b.classList.toggle('active', b.textContent === icon));
  for (const candidate of NAV_ICONS) {
    const btn = mk('button', { class: 'icon-picker-item', type: 'button', title: candidate }, candidate);
    btn.addEventListener('click', () => { icon = candidate; paintGrid(); });
    iconGrid.appendChild(btn);
  }
  const syncIconState = () => {
    const isChildRow = parentSelect.value !== '';
    iconGrid.classList.toggle('disabled', isChildRow);
  };
  parentSelect.addEventListener('change', syncIconState);
  syncIconState();
  addRow('图标', iconGrid);
  paintGrid();

  // 地址：内置页面只读，新增/自定义菜单可填路径或网址
  const hrefEditable = isNew || !!custom;
  const hrefInput = mk('input', { type: 'text', placeholder: 'cons.html / https://example.com' });
  hrefInput.value = custom ? (custom.href || '') : (builtin ? (builtin.href || '内置页面') : '');
  hrefInput.disabled = !hrefEditable;
  addRow('地址', hrefInput);

  // 打开方式：只有新增/自定义菜单可选
  const newTabWrap = mk('label', { class: 'checkbox-label' });
  const newTab = mk('input', { type: 'checkbox' });
  newTab.checked = custom ? custom.newTab !== false : !!builtin?.newTab;
  newTab.disabled = !hrefEditable;
  newTabWrap.appendChild(newTab);
  newTabWrap.appendChild(document.createTextNode(' 在新窗口打开'));
  addRow('打开方式', newTabWrap);

  // 显示：菜单管理自身锁定为始终显示
  const visWrap = mk('label', { class: 'checkbox-label' });
  const vis = mk('input', { type: 'checkbox' });
  vis.checked = isNew ? true : (custom ? custom.visible !== false : menuVisible(key));
  vis.disabled = !!builtin?.locked;
  visWrap.appendChild(vis);
  visWrap.appendChild(document.createTextNode(' 在导航中显示'));
  addRow('显示', visWrap);

  openModal({
    title: isNew ? '新增自定义菜单' : '编辑菜单',
    body,
    actions: [
      { label: '取消', onClick: closeModal },
      {
        label: isNew ? '添加' : '保存',
        className: 'primary',
        onClick: async () => {
          const label = nameInput.value.trim();
          if (!label) { toastErr('请填写菜单名称'); return; }
          const parentValue = parentSelect.value;
          if (isNew || custom) {
            // 地址可以留空：只作为分组使用，点击没有跳转
            const href = hrefInput.value.trim();
            const next = clone(state.menu);
            if (isNew) {
              const id = mint('menu');
              next.custom.push({ id, label, href, icon, newTab: newTab.checked });
              appendMenuKey(next, id, parentValue);
            } else {
              const target = next.custom.find(c => c.id === key);
              target.label = label;
              target.href = href;
              target.icon = icon;
              if (newTab.checked) delete target.newTab; else target.newTab = false;
              if (vis.checked) delete target.visible; else target.visible = false;
              if (findMenuParent(next, key) !== parentValue) {
                detachMenuKey(next, key);
                appendMenuKey(next, key, parentValue);
              }
            }
            await saveMenuConfig(next, { rerender: true });
          } else {
            const patch = { label, visible: vis.checked ? undefined : false };
            if (builtinParent !== 'child') patch.icon = icon;
            await updateMenuOverride(key, patch);
          }
          closeModal();
          toastOk(isNew ? `已新增菜单「${label}」` : '菜单已更新（草稿）');
        },
      },
    ],
  });
}

// 菜单行：按层级展开，parent 为空串表示一级导航
function menuRowList() {
  const rows = [];
  const walk = (keys, parent) => {
    for (const key of keys) {
      rows.push({ key, parent });
      walk(state.menu.children[key] || [], key);
    }
  };
  walk(state.menu.order, '');
  return rows;
}

// 与「字典设置」同一套页面结构：工具栏（搜索 + 数量）+ 表格 + 右栏操作
function buildMenuSection() {
  const wrap = mk('div', { class: 'setting-block' });

  const bar = mk('div', { class: 'toolbar' });
  const search = mk('input', { type: 'search', placeholder: '搜索菜单名称 / 地址' });
  search.value = state.menuSearch || '';
  bar.appendChild(search);
  const info = mk('span', { class: 'hint' });
  bar.appendChild(info);
  const resetBtn = mk('button', { class: 'btn small', style: 'margin-left:auto;' }, '恢复默认');
  resetBtn.addEventListener('click', resetMenuConfig);
  bar.appendChild(resetBtn);
  wrap.appendChild(bar);

  const tableWrap = mk('div', { class: 'table-wrap' });
  wrap.appendChild(tableWrap);

  const selected = () => Array.from(state.menuChecked)
    .map(key => menuRowList().find(row => row.key === key)).filter(Boolean);

  pendingRail = buildSettingRail({
    label: '菜单',
    count: state.menuChecked.size,
    onNew: () => openMenuDialog(null),
    onUp: () => {
      const sel = selected()[0];
      if (sel) moveMenuKey(sel.key, -1, sel.parent);
    },
    onDown: () => {
      const sel = selected()[0];
      if (sel) moveMenuKey(sel.key, 1, sel.parent);
    },
    onDelete: () => { const sel = selected()[0]; if (sel) removeCustomMenu(sel.key); },
  });

  const renderTable = () => {
    const kw = (state.menuSearch || '').trim().toLowerCase();
    const rows = menuRowList();
    const list = rows.filter(({ key }) => {
      if (!kw) return true;
      const custom = state.menu.custom.find(c => c.id === key);
      return `${menuLabel(key)} ${custom?.href || ''}`.toLowerCase().includes(kw);
    });
    tableWrap.innerHTML = '';
    info.textContent = `共 ${list.length} 个`;
    if (!list.length) {
      tableWrap.appendChild(mk('div', { class: 'empty', style: 'padding:24px;' },
        kw ? '没有匹配的菜单' : '还没有菜单'));
      return;
    }

    const table = mk('table', { class: 'grid' });
    const head = mk('tr');
    ['', '图标', '菜单名称', '所属', '地址 / 类型', '显示', '操作'].forEach((t, i) => {
      const th = mk('th', {}, t);
      if (i === 6) th.className = 'col-ops';
      head.appendChild(th);
    });
    table.appendChild(head);

    for (const { key, parent } of list) {
      const isChild = !!parent;
      const builtin = NAV_BUILTINS[key] || NAV_BUILTINS.settings.children[key] || null;
      const custom = builtin ? null : state.menu.custom.find(c => c.id === key);
      const locked = !!builtin?.locked;
      const tr = mk('tr');

      const cb = mk('input', { type: 'checkbox' });
      cb.checked = state.menuChecked.has(key);
      cb.addEventListener('change', () => {
        state.menuChecked.delete(key);
        if (cb.checked) state.menuChecked.add(key);
        render();
      });
      const chkTd = mk('td');
      chkTd.appendChild(cb);
      tr.appendChild(chkTd);

      tr.appendChild(mk('td', {}, isChild ? '—' : menuIcon(key)));
      tr.appendChild(mk('td', { class: 'plain' }, custom ? custom.label : menuLabel(key)));
      const parentLabel = parent === '' ? '主导航'
        : parent === 'settings' ? '系统设置' : menuLabel(parent);
      tr.appendChild(mk('td', {}, parentLabel));
      tr.appendChild(mk('td', { class: 'wrap' }, custom ? (custom.href || '—') : (builtin?.href || '内置页面')));
      const visible = custom ? custom.visible !== false : menuVisible(key);
      tr.appendChild(mk('td', { class: 'plain' }, locked ? '始终显示' : (visible ? '显示' : '隐藏')));

      // 操作列：编辑 / 删除；内置菜单不可删除
      const ops = mk('td', { class: 'col-ops' });
      const edit = mk('button', { class: 'link-btn', type: 'button' }, '编辑');
      edit.addEventListener('click', () => openMenuDialog(key));
      ops.appendChild(edit);
      if (custom) {
        const del = mk('button', { class: 'link-btn danger', type: 'button' }, '删除');
        del.addEventListener('click', () => removeCustomMenu(key));
        ops.appendChild(del);
      }
      tr.appendChild(ops);
      table.appendChild(tr);
    }

    // 底部固定项：返回官网，与上方菜单用分隔线区分
    if (!kw || NAV_FOOTER.label.includes(kw)) {
      const tr = mk('tr');
      tr.appendChild(mk('td'));
      tr.appendChild(mk('td', {}, NAV_FOOTER.icon));
      tr.appendChild(mk('td', { class: 'plain' }, NAV_FOOTER.label));
      tr.appendChild(mk('td', {}, '导航底部'));
      tr.appendChild(mk('td', { class: 'wrap' }, NAV_FOOTER.href));
      tr.appendChild(mk('td', { class: 'plain' }, '固定'));
      const ops = mk('td', { class: 'col-ops' });
      ops.appendChild(mk('span', { class: 'menu-lock' }, '固定'));
      tr.appendChild(ops);
      table.appendChild(tr);
    }

    tableWrap.appendChild(table);
  };

  search.addEventListener('input', () => { state.menuSearch = search.value; renderTable(); });
  renderTable();
  return wrap;
}

function draftLabel(d) {
  const opText = { add: '新增', update: '修改', delete: '删除' }[d.op] || d.op;
  if (d.kind === 'category') {
    return `【分组】${opText} ${d.data?.name || d.recordId}`;
  }
  if (d.kind === 'dictionary') {
    return `【字典】${opText} ${d.data?.name || d.recordId}（${d.data?.items?.length || 0} 项）`;
  }
  if (d.kind === 'attrSet') {
    return `【属性集合】${opText} ${d.data?.name || d.recordId}（${d.data?.attrs?.length || 0} 个属性）`;
  }
  if (d.kind === 'menu') {
    return '【菜单】调整导航菜单（顺序 / 显隐 / 名称 / 图标 / 自定义项）';
  }
  const catName = d.data?.categoryId ? Cat.categoryPathString(state.categories, d.data.categoryId) : '';
  return `【物料】${opText} ${d.data?.code || '待提交'}${d.data?.name ? ' ' + d.data.name : ''}${catName ? '（' + catName + '）' : ''}`;
}

async function discardAllDrafts() {
  if (!state.drafts.length) return;
  if (!(await confirm('丢弃全部未提交改动？此操作不可恢复。'))) return;
  await Store.clearAllCache();
  await loadDrafts();
  render();
  toastOk('已清空全部草稿');
}

// ---------- 提交 ----------
async function buildCommitPayload(selectedDrafts, includeInit) {
  const now = nowISO();
  const sets = {};
  for (const s of DATA_SETS) sets[s.kind] = clone(state[s.base]);

  for (const d of selectedDrafts) {
    const target = sets[d.kind];
    if (!target) continue;
    const idx = target.findIndex(x => x.id === d.recordId);
    if (d.op === 'delete') {
      if (idx >= 0) target.splice(idx, 1);
      continue;
    }
    const next = clone(d.data);
    if (idx >= 0) target[idx] = next; else target.push(next);
  }

  const fileChanges = [];
  for (const s of DATA_SETS) {
    const text = JSON.stringify(sets[s.kind], null, 2) + '\n';
    const touched = selectedDrafts.some(d => d.kind === s.kind);
    const missing = state[s.raw] === null;
    if (missing ? (includeInit || touched) : text !== state[s.raw]) {
      fileChanges.push({ path: s.path, content: text });
    }
  }
  const menuDraft = selectedDrafts.find(d => d.kind === 'menu');
  if (menuDraft) {
    const text = JSON.stringify(normalizeMenu(menuDraft.data), null, 2) + '\n';
    if (text !== state.rawMenuText) fileChanges.push({ path: CONFIG.menuPath, content: text });
  }

  const materialPayload = await MaterialStore.buildCommitPayload(selectedDrafts, now, includeInit);
  return {
    fileChanges: fileChanges.concat(materialPayload.fileChanges),
    treeDeletes: materialPayload.treeDeletes,
  };
}

// 提交已经落库：以本次 payload 为新基准，保留未提交草稿，并同步新 head 下的缓存。
async function applyCommittedPayload(payload, commitSha) {
  const oldHead = state.remoteHead;
  state.remoteHead = commitSha;
  GH.setCacheContext(state.cacheNs, commitSha);
  await GH.applyCommitToCache(oldHead, payload);

  const changes = new Map(payload.fileChanges.map(change => [change.path, change]));
  for (const s of DATA_SETS) {
    const change = changes.get(s.path);
    if (!change) continue;
    state[s.raw] = change.content;
    state[s.base] = safeParse(change.content, []);
  }

  const menuChange = changes.get(CONFIG.menuPath);
  if (menuChange) {
    state.rawMenuText = menuChange.content;
    state.baseMenu = normalizeMenu(safeParse(menuChange.content, defaultMenuConfig()));
  }

  state.baseMaterials = await MaterialStore.applyCommitPayload(payload);
  state.indexLoaded = true;
  state.indexRefreshed = true;
  const written = new Set(payload.fileChanges.map(change => change.path));
  state.missingDataFiles = state.missingDataFiles.filter(path => !written.has(path));
  await Store.setMeta(indexCacheKey(), state.baseMaterials).catch(e => console.warn('缓存物料索引失败', e));
  await loadDrafts();
  await autoFixLooseMaterials();
}

async function doCommit(selectedIds, message, btn, includeInit) {
  let draftsToSubmit = state.drafts.filter(d => selectedIds.includes(d.id));
  btn.disabled = true;
  const oldText = btn.textContent;

  // 索引还在后台加载时先等它，避免拿旧/空索引生成提交内容
  if (!state.indexRefreshed) {
    btn.textContent = '等待物料索引…';
    await state.indexPromise?.catch(() => {});
    // 后台加载失败过一次时，提交前再试一次
    if (!state.indexRefreshed) {
      state.indexPromise = loadMaterialIndex();
      await state.indexPromise.catch(() => {});
    }
  }
  if (!state.indexRefreshed) {
    toastErr('物料索引尚未加载完成，请稍候再提交');
    btn.disabled = false;
    btn.textContent = oldText;
    return;
  }

  btn.textContent = '提交中…';

  for (let attempt = 0; ; attempt++) {
    try {
      progressStart('整理提交内容…');
      // 新增物料的编码在这里按远端最新数据分配
      const prepared = await prepareDraftsWithCodes(draftsToSubmit);
      const { fileChanges, treeDeletes } = await buildCommitPayload(prepared, includeInit);
      if (!fileChanges.length) {
        toastErr('内容与远端一致，无需提交');
        btn.disabled = false;
        btn.textContent = oldText;
        progressEnd();
        return;
      }

      const fallback = draftsToSubmit.length
        ? `chore: Craft 系统提交（${draftsToSubmit.length} 项）`
        : 'chore: 初始化数据仓库';
      const result = await GH.singleCommit({
        message: message || fallback,
        baseCommit: state.remoteHead,
        treeChanges: fileChanges,
        treeDeletes,
        onProgress: (done, total, label) => progressSet(done, total, label),
      });

      // 清掉已提交的草稿
      for (const d of draftsToSubmit) {
        const [kind, id] = d.id.split(/:(.+)/);
        await Store.removeDraft(kind, id);
      }
      await applyCommittedPayload({ fileChanges, treeDeletes }, result.commitSha);
      progressEnd();
      toastOk(`已提交，commit ${result.commitSha.slice(0, 7)}`);
      render();
      return;
    } catch (e) {
      // 别人先提交了：同步最新数据后重新分配编码并自动重试一次
      if (e.code === 'CONFLICT' && attempt === 0) {
        toast('远端已更新，正在重新同步并重试…');
        const refreshed = await refreshRemote({ awaitIndex: true });
        if (!refreshed) {
          btn.disabled = false;
          btn.textContent = oldText;
          progressEnd();
          toastErr('提交失败：物料索引刷新失败，请重试');
          render();
          return;
        }
        await loadDrafts();
        draftsToSubmit = state.drafts.filter(d => selectedIds.includes(d.id));
        if (!draftsToSubmit.length) {
          btn.disabled = false;
          btn.textContent = oldText;
          progressEnd();
          toastErr('草稿已不存在，请重新操作');
          render();
          return;
        }
        continue;
      }
      btn.disabled = false;
      btn.textContent = oldText;
      progressEnd();
      toastErr('提交失败：' + (e.message || e));
      console.error(e);
      return;
    }
  }
}

// ---------- loading ----------
function setLoading() {
  const content = document.getElementById('content');
  content.className = 'content';
  content.innerHTML = '';
  content.appendChild(mk('div', { class: 'loading' }, '加载中…'));
}

// ---------- 顶部进度条 ----------
let progressTotal = 0;
let progressDone = 0;

function progressEls() {
  return {
    wrap: document.getElementById('appProgress'),
    fill: document.getElementById('appProgressFill'),
    text: document.getElementById('appProgressText'),
  };
}

function progressStart(label) {
  const { wrap, fill, text } = progressEls();
  if (!wrap) return;
  progressTotal = 0;
  progressDone = 0;
  wrap.hidden = false;
  wrap.classList.add('indeterminate');
  fill.style.width = '';
  text.textContent = label || '';
}

function progressSet(done, total, label) {
  const { wrap, fill, text } = progressEls();
  if (!wrap) return;
  progressDone = done;
  progressTotal = total;
  wrap.hidden = false;
  wrap.classList.remove('indeterminate');
  fill.style.width = `${total ? Math.min(100, (done / total) * 100) : 0}%`;
  if (label) text.textContent = total ? `${label} ${done}/${total}` : label;
}

function progressAdvance(label) {
  if (!progressTotal) return;
  progressSet(Math.min(progressDone + 1, progressTotal), progressTotal, label);
}

function progressEnd() {
  const { wrap } = progressEls();
  if (!wrap) return;
  wrap.hidden = true;
  wrap.classList.remove('indeterminate');
}

